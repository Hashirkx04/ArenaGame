import { useState, useEffect, useCallback } from "react";

const RATINGS_KEY = "gameArenaRatings";

interface GameRatings {
  [gameId: string]: number;
}

export const useGameRatings = () => {
  const [ratings, setRatings] = useState<GameRatings>({});

  useEffect(() => {
    const stored = localStorage.getItem(RATINGS_KEY);
    if (stored) {
      try {
        setRatings(JSON.parse(stored));
      } catch {
        setRatings({});
      }
    }
  }, []);

  const setRating = useCallback((gameId: string, rating: number) => {
    setRatings((prev) => {
      const newRatings = { ...prev, [gameId]: rating };
      localStorage.setItem(RATINGS_KEY, JSON.stringify(newRatings));
      return newRatings;
    });
  }, []);

  const getRating = useCallback((gameId: string): number => {
    return ratings[gameId] || 0;
  }, [ratings]);

  return { ratings, setRating, getRating };
};
