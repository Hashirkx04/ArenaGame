import { useEffect, useRef, useState } from "react";

interface AudioSettings {
  volume: number;
  isMuted: boolean;
}

export const useGameAudio = () => {
  const [settings, setSettings] = useState<AudioSettings>({
    volume: 0.5,
    isMuted: false,
  });
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const backgroundMusicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Load settings from localStorage
    const saved = localStorage.getItem("gameAudioSettings");
    if (saved) {
      setSettings(JSON.parse(saved));
    }

    // Initialize audio context
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();

    return () => {
      if (backgroundMusicRef.current) {
        backgroundMusicRef.current.pause();
        backgroundMusicRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    // Save settings to localStorage
    localStorage.setItem("gameAudioSettings", JSON.stringify(settings));
  }, [settings]);

  const playSound = (frequency: number, duration: number, type: OscillatorType = "sine") => {
    if (settings.isMuted || !audioContextRef.current) return;

    const ctx = audioContextRef.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gainNode.gain.value = settings.volume;

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
  };

  const playClickSound = () => playSound(800, 0.1, "sine");
  const playSuccessSound = () => {
    playSound(523.25, 0.1, "sine");
    setTimeout(() => playSound(659.25, 0.1, "sine"), 100);
    setTimeout(() => playSound(783.99, 0.2, "sine"), 200);
  };
  const playErrorSound = () => {
    playSound(200, 0.1, "square");
    setTimeout(() => playSound(150, 0.2, "square"), 100);
  };
  const playGameOverSound = () => {
    playSound(392, 0.2, "triangle");
    setTimeout(() => playSound(349.23, 0.2, "triangle"), 200);
    setTimeout(() => playSound(293.66, 0.4, "triangle"), 400);
  };
  const playWinSound = () => {
    [523.25, 587.33, 659.25, 783.99].forEach((freq, i) => {
      setTimeout(() => playSound(freq, 0.15, "sine"), i * 100);
    });
  };
  const playMoveSound = () => playSound(440, 0.05, "sine");
  const playCollectSound = () => {
    playSound(880, 0.05, "sine");
    setTimeout(() => playSound(1046.5, 0.1, "sine"), 50);
  };

  const playBackgroundMusic = (loop = true) => {
    if (settings.isMuted) return;
    
    // Simple background music using oscillators
    if (!audioContextRef.current) return;
    
    const ctx = audioContextRef.current;
    const notes = [261.63, 293.66, 329.63, 392, 440, 523.25]; // C major scale
    let currentNote = 0;

    const playNote = () => {
      if (settings.isMuted) return;
      playSound(notes[currentNote], 0.3, "sine");
      currentNote = (currentNote + 1) % notes.length;
      if (loop) {
        setTimeout(playNote, 500);
      }
    };

    playNote();
  };

  const setVolume = (volume: number) => {
    setSettings((prev) => ({ ...prev, volume: Math.max(0, Math.min(1, volume)) }));
  };

  const toggleMute = () => {
    setSettings((prev) => ({ ...prev, isMuted: !prev.isMuted }));
  };

  return {
    volume: settings.volume,
    isMuted: settings.isMuted,
    setVolume,
    toggleMute,
    playClickSound,
    playSuccessSound,
    playErrorSound,
    playGameOverSound,
    playWinSound,
    playMoveSound,
    playCollectSound,
    playBackgroundMusic,
  };
};
