import { useState, useEffect } from 'react';

export interface GameStats {
  gamesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  totalScore: number;
  highScore: number;
  totalTimePlayed: number; // in seconds
  lastPlayed?: string;
}

export interface AllGameStats {
  [gameId: string]: GameStats;
}

const defaultStats: GameStats = {
  gamesPlayed: 0,
  wins: 0,
  losses: 0,
  draws: 0,
  totalScore: 0,
  highScore: 0,
  totalTimePlayed: 0,
};

export const useGameStats = () => {
  const [stats, setStats] = useState<AllGameStats>(() => {
    const saved = localStorage.getItem('gameArenaStats');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('gameArenaStats', JSON.stringify(stats));
  }, [stats]);

  const getGameStats = (gameId: string): GameStats => {
    return stats[gameId] || defaultStats;
  };

  const updateGameStats = (
    gameId: string,
    update: {
      win?: boolean;
      loss?: boolean;
      draw?: boolean;
      score?: number;
      timePlayed?: number;
    }
  ) => {
    setStats((prev) => {
      const gameStats = prev[gameId] || defaultStats;
      
      return {
        ...prev,
        [gameId]: {
          gamesPlayed: gameStats.gamesPlayed + 1,
          wins: gameStats.wins + (update.win ? 1 : 0),
          losses: gameStats.losses + (update.loss ? 1 : 0),
          draws: gameStats.draws + (update.draw ? 1 : 0),
          totalScore: gameStats.totalScore + (update.score || 0),
          highScore: Math.max(gameStats.highScore, update.score || 0),
          totalTimePlayed: gameStats.totalTimePlayed + (update.timePlayed || 0),
          lastPlayed: new Date().toISOString(),
        },
      };
    });
  };

  const getAllStats = (): AllGameStats => {
    return stats;
  };

  const getTotalStats = () => {
    const allGames = Object.values(stats);
    return {
      totalGamesPlayed: allGames.reduce((sum, game) => sum + game.gamesPlayed, 0),
      totalWins: allGames.reduce((sum, game) => sum + game.wins, 0),
      totalLosses: allGames.reduce((sum, game) => sum + game.losses, 0),
      totalDraws: allGames.reduce((sum, game) => sum + game.draws, 0),
      totalScore: allGames.reduce((sum, game) => sum + game.totalScore, 0),
      totalTimePlayed: allGames.reduce((sum, game) => sum + game.totalTimePlayed, 0),
    };
  };

  const resetStats = (gameId?: string) => {
    if (gameId) {
      setStats((prev) => {
        const newStats = { ...prev };
        delete newStats[gameId];
        return newStats;
      });
    } else {
      setStats({});
    }
  };

  return {
    getGameStats,
    updateGameStats,
    getAllStats,
    getTotalStats,
    resetStats,
  };
};
