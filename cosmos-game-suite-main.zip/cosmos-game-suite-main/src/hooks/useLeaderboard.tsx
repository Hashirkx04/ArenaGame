import { useState, useEffect } from "react";

const LEADERBOARD_KEY = "gameArenaLeaderboard";

export interface LeaderboardEntry {
  gameId: string;
  playerName: string;
  score: number;
  date: string;
}

interface LeaderboardData {
  [gameId: string]: LeaderboardEntry[];
}

const MAX_ENTRIES_PER_GAME = 10;

export const useLeaderboard = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardData>({});

  useEffect(() => {
    const stored = localStorage.getItem(LEADERBOARD_KEY);
    if (stored) {
      try {
        setLeaderboard(JSON.parse(stored));
      } catch {
        setLeaderboard({});
      }
    }
  }, []);

  const addScore = (gameId: string, playerName: string, score: number) => {
    setLeaderboard((prev) => {
      const gameScores = prev[gameId] || [];
      const newEntry: LeaderboardEntry = {
        gameId,
        playerName: playerName || "Anonymous",
        score,
        date: new Date().toISOString(),
      };

      const updatedScores = [...gameScores, newEntry]
        .sort((a, b) => b.score - a.score)
        .slice(0, MAX_ENTRIES_PER_GAME);

      const newLeaderboard = { ...prev, [gameId]: updatedScores };
      localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(newLeaderboard));
      return newLeaderboard;
    });
  };

  const getTopScores = (gameId: string, limit: number = 5): LeaderboardEntry[] => {
    return (leaderboard[gameId] || []).slice(0, limit);
  };

  const getHighScore = (gameId: string): number => {
    const scores = leaderboard[gameId] || [];
    return scores.length > 0 ? scores[0].score : 0;
  };

  const getAllTopScores = (): { gameId: string; entry: LeaderboardEntry }[] => {
    const topScores: { gameId: string; entry: LeaderboardEntry }[] = [];
    Object.keys(leaderboard).forEach((gameId) => {
      const scores = leaderboard[gameId];
      if (scores && scores.length > 0) {
        topScores.push({ gameId, entry: scores[0] });
      }
    });
    return topScores.sort((a, b) => b.entry.score - a.entry.score);
  };

  const clearLeaderboard = () => {
    setLeaderboard({});
    localStorage.removeItem(LEADERBOARD_KEY);
  };

  return { leaderboard, addScore, getTopScores, getHighScore, getAllTopScores, clearLeaderboard };
};
