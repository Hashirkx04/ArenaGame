import { useState, useEffect, useCallback } from "react";

const ACHIEVEMENTS_KEY = "gameArenaAchievements";
const PROGRESS_KEY = "gameArenaProgress";

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  requirement: number;
  category: "games" | "scores" | "social" | "special";
}

export const achievements: Achievement[] = [
  // Games played achievements
  { id: "first_game", title: "First Steps", description: "Play your first game", icon: "🎮", requirement: 1, category: "games" },
  { id: "casual_player", title: "Casual Player", description: "Play 10 games", icon: "🕹️", requirement: 10, category: "games" },
  { id: "dedicated_gamer", title: "Dedicated Gamer", description: "Play 50 games", icon: "🎯", requirement: 50, category: "games" },
  { id: "gaming_legend", title: "Gaming Legend", description: "Play 100 games", icon: "👑", requirement: 100, category: "games" },
  
  // Score achievements
  { id: "score_hunter", title: "Score Hunter", description: "Submit your first high score", icon: "🏆", requirement: 1, category: "scores" },
  { id: "high_achiever", title: "High Achiever", description: "Submit 10 high scores", icon: "⭐", requirement: 10, category: "scores" },
  { id: "score_master", title: "Score Master", description: "Submit 25 high scores", icon: "💎", requirement: 25, category: "scores" },
  
  // Social achievements
  { id: "first_favorite", title: "Found a Favorite", description: "Add your first favorite game", icon: "❤️", requirement: 1, category: "social" },
  { id: "collector", title: "Game Collector", description: "Add 5 games to favorites", icon: "💖", requirement: 5, category: "social" },
  { id: "critic", title: "Game Critic", description: "Rate your first game", icon: "⭐", requirement: 1, category: "social" },
  { id: "reviewer", title: "Expert Reviewer", description: "Rate 10 games", icon: "📝", requirement: 10, category: "social" },
  
  // Special achievements
  { id: "explorer", title: "Explorer", description: "Try 5 different games", icon: "🗺️", requirement: 5, category: "special" },
  { id: "variety_seeker", title: "Variety Seeker", description: "Try 15 different games", icon: "🌟", requirement: 15, category: "special" },
  { id: "completionist", title: "Completionist", description: "Try all 28 games", icon: "🏅", requirement: 28, category: "special" },
];

interface Progress {
  gamesPlayed: number;
  scoresSubmitted: number;
  favoritesAdded: number;
  gamesRated: number;
  uniqueGamesPlayed: string[];
}

interface UnlockedAchievement {
  id: string;
  unlockedAt: string;
}

export const useAchievements = () => {
  const [unlockedAchievements, setUnlockedAchievements] = useState<UnlockedAchievement[]>([]);
  const [progress, setProgress] = useState<Progress>({
    gamesPlayed: 0,
    scoresSubmitted: 0,
    favoritesAdded: 0,
    gamesRated: 0,
    uniqueGamesPlayed: [],
  });
  const [newlyUnlocked, setNewlyUnlocked] = useState<Achievement | null>(null);

  useEffect(() => {
    const storedAchievements = localStorage.getItem(ACHIEVEMENTS_KEY);
    const storedProgress = localStorage.getItem(PROGRESS_KEY);
    
    if (storedAchievements) {
      try {
        setUnlockedAchievements(JSON.parse(storedAchievements));
      } catch {
        setUnlockedAchievements([]);
      }
    }
    
    if (storedProgress) {
      try {
        setProgress(JSON.parse(storedProgress));
      } catch {
        // Keep default progress
      }
    }
  }, []);

  const checkAndUnlockAchievements = useCallback((newProgress: Progress) => {
    const toUnlock: Achievement[] = [];

    achievements.forEach((achievement) => {
      const isAlreadyUnlocked = unlockedAchievements.some((u) => u.id === achievement.id);
      if (isAlreadyUnlocked) return;

      let shouldUnlock = false;

      switch (achievement.id) {
        case "first_game":
        case "casual_player":
        case "dedicated_gamer":
        case "gaming_legend":
          shouldUnlock = newProgress.gamesPlayed >= achievement.requirement;
          break;
        case "score_hunter":
        case "high_achiever":
        case "score_master":
          shouldUnlock = newProgress.scoresSubmitted >= achievement.requirement;
          break;
        case "first_favorite":
        case "collector":
          shouldUnlock = newProgress.favoritesAdded >= achievement.requirement;
          break;
        case "critic":
        case "reviewer":
          shouldUnlock = newProgress.gamesRated >= achievement.requirement;
          break;
        case "explorer":
        case "variety_seeker":
        case "completionist":
          shouldUnlock = newProgress.uniqueGamesPlayed.length >= achievement.requirement;
          break;
      }

      if (shouldUnlock) {
        toUnlock.push(achievement);
      }
    });

    if (toUnlock.length > 0) {
      const newUnlocked = toUnlock.map((a) => ({
        id: a.id,
        unlockedAt: new Date().toISOString(),
      }));

      setUnlockedAchievements((prev) => {
        const updated = [...prev, ...newUnlocked];
        localStorage.setItem(ACHIEVEMENTS_KEY, JSON.stringify(updated));
        return updated;
      });

      // Show the first newly unlocked achievement
      setNewlyUnlocked(toUnlock[0]);
      setTimeout(() => setNewlyUnlocked(null), 4000);
    }
  }, [unlockedAchievements]);

  const trackGamePlayed = useCallback((gameId: string) => {
    setProgress((prev) => {
      const uniqueGames = prev.uniqueGamesPlayed.includes(gameId)
        ? prev.uniqueGamesPlayed
        : [...prev.uniqueGamesPlayed, gameId];

      const newProgress = {
        ...prev,
        gamesPlayed: prev.gamesPlayed + 1,
        uniqueGamesPlayed: uniqueGames,
      };

      localStorage.setItem(PROGRESS_KEY, JSON.stringify(newProgress));
      setTimeout(() => checkAndUnlockAchievements(newProgress), 100);
      return newProgress;
    });
  }, [checkAndUnlockAchievements]);

  const trackScoreSubmitted = useCallback(() => {
    setProgress((prev) => {
      const newProgress = {
        ...prev,
        scoresSubmitted: prev.scoresSubmitted + 1,
      };
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(newProgress));
      setTimeout(() => checkAndUnlockAchievements(newProgress), 100);
      return newProgress;
    });
  }, [checkAndUnlockAchievements]);

  const trackFavoriteAdded = useCallback(() => {
    setProgress((prev) => {
      const newProgress = {
        ...prev,
        favoritesAdded: prev.favoritesAdded + 1,
      };
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(newProgress));
      setTimeout(() => checkAndUnlockAchievements(newProgress), 100);
      return newProgress;
    });
  }, [checkAndUnlockAchievements]);

  const trackGameRated = useCallback(() => {
    setProgress((prev) => {
      const newProgress = {
        ...prev,
        gamesRated: prev.gamesRated + 1,
      };
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(newProgress));
      setTimeout(() => checkAndUnlockAchievements(newProgress), 100);
      return newProgress;
    });
  }, [checkAndUnlockAchievements]);

  const isUnlocked = (achievementId: string) => {
    return unlockedAchievements.some((u) => u.id === achievementId);
  };

  const getUnlockDate = (achievementId: string) => {
    const unlocked = unlockedAchievements.find((u) => u.id === achievementId);
    return unlocked ? new Date(unlocked.unlockedAt) : null;
  };

  return {
    achievements,
    unlockedAchievements,
    progress,
    newlyUnlocked,
    trackGamePlayed,
    trackScoreSubmitted,
    trackFavoriteAdded,
    trackGameRated,
    isUnlocked,
    getUnlockDate,
    dismissNewlyUnlocked: () => setNewlyUnlocked(null),
  };
};
