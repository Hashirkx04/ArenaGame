import { useState } from "react";

const MAX_RECENT_GAMES = 4;

export const useRecentGames = () => {
  const [recentGames, setRecentGames] = useState<string[]>([]);

  const addRecentGame = (gameId: string) => {
    setRecentGames((prev) => {
      const filtered = prev.filter((id) => id !== gameId);
      const newRecent = [gameId, ...filtered].slice(0, MAX_RECENT_GAMES);
      return newRecent;
    });
  };

  return { recentGames, addRecentGame };
};
