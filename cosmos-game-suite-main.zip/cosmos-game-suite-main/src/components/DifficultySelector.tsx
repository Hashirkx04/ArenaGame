import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Zap, Timer, Flame } from "lucide-react";

export type Difficulty = "easy" | "medium" | "hard";

interface DifficultySelectorProps {
  difficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
  disabled?: boolean;
}

const DifficultySelector = ({ difficulty, onDifficultyChange, disabled = false }: DifficultySelectorProps) => {
  const difficulties: { value: Difficulty; label: string; icon: typeof Zap; color: string }[] = [
    { value: "easy", label: "Easy", icon: Timer, color: "text-green-500" },
    { value: "medium", label: "Medium", icon: Zap, color: "text-yellow-500" },
    { value: "hard", label: "Hard", icon: Flame, color: "text-red-500" },
  ];

  return (
    <Card className="p-4 bg-card/50 backdrop-blur-sm border-border">
      <div className="flex flex-col gap-2">
        <p className="text-sm text-muted-foreground text-center">Difficulty</p>
        <div className="flex gap-2">
          {difficulties.map(({ value, label, icon: Icon, color }) => (
            <Button
              key={value}
              variant={difficulty === value ? "default" : "outline"}
              size="sm"
              onClick={() => onDifficultyChange(value)}
              disabled={disabled}
              className={`flex-1 ${difficulty === value ? "" : "border-border hover:border-primary"}`}
            >
              <Icon className={`w-4 h-4 mr-2 ${difficulty === value ? "" : color}`} />
              {label}
            </Button>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default DifficultySelector;
