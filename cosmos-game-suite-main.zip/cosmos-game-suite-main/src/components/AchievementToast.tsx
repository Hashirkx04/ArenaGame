import { Achievement } from "@/hooks/useAchievements";
import { X } from "lucide-react";

interface AchievementToastProps {
  achievement: Achievement;
  onDismiss: () => void;
}

export const AchievementToast = ({ achievement, onDismiss }: AchievementToastProps) => {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
      <div className="bg-gradient-to-r from-yellow-500/90 to-yellow-600/90 backdrop-blur-lg rounded-xl p-4 shadow-2xl border border-yellow-400/50 flex items-center gap-4 min-w-[300px]">
        <div className="text-4xl animate-bounce">{achievement.icon}</div>
        <div className="flex-1">
          <p className="text-xs text-yellow-100 font-medium uppercase tracking-wide">Achievement Unlocked!</p>
          <p className="text-lg font-bold text-white">{achievement.title}</p>
          <p className="text-sm text-yellow-100">{achievement.description}</p>
        </div>
        <button
          onClick={onDismiss}
          className="text-yellow-100 hover:text-white transition-colors"
          aria-label="Dismiss"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
