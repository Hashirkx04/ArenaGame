import { Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";
import { Slider } from "./ui/slider";
import { Card } from "./ui/card";

interface AudioControlsProps {
  volume: number;
  isMuted: boolean;
  onVolumeChange: (volume: number) => void;
  onToggleMute: () => void;
}

const AudioControls = ({ volume, isMuted, onVolumeChange, onToggleMute }: AudioControlsProps) => {
  return (
    <Card className="p-4 bg-card/50 backdrop-blur-sm border-border">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={onToggleMute}
          className="border-border hover:border-primary shrink-0"
        >
          {isMuted ? (
            <VolumeX className="h-4 w-4" />
          ) : (
            <Volume2 className="h-4 w-4" />
          )}
        </Button>
        <div className="flex-1">
          <Slider
            value={[isMuted ? 0 : volume * 100]}
            onValueChange={(value) => onVolumeChange(value[0] / 100)}
            max={100}
            step={1}
            className="w-full"
            disabled={isMuted}
          />
        </div>
        <span className="text-sm text-muted-foreground min-w-[3ch] text-right">
          {isMuted ? 0 : Math.round(volume * 100)}%
        </span>
      </div>
    </Card>
  );
};

export default AudioControls;
