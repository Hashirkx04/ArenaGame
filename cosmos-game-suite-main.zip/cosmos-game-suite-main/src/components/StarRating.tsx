import { Star } from "lucide-react";
import { useState } from "react";

interface StarRatingProps {
  rating: number;
  onRate?: (rating: number) => void;
  readonly?: boolean;
  size?: "sm" | "md";
}

export const StarRating = ({ rating, onRate, readonly = false, size = "md" }: StarRatingProps) => {
  const [hoverRating, setHoverRating] = useState(0);

  const starSize = size === "sm" ? "w-3.5 h-3.5" : "w-5 h-5";

  const handleClick = (e: React.MouseEvent, star: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (!readonly && onRate) {
      onRate(star);
    }
  };

  return (
    <div 
      className="flex gap-0.5"
      onMouseLeave={() => !readonly && setHoverRating(0)}
    >
      {[1, 2, 3, 4, 5].map((star) => {
        const isFilled = star <= (hoverRating || rating);
        return (
          <button
            key={star}
            type="button"
            onClick={(e) => handleClick(e, star)}
            onMouseEnter={() => !readonly && setHoverRating(star)}
            disabled={readonly}
            className={`transition-all duration-150 ${
              readonly ? "cursor-default" : "cursor-pointer hover:scale-110"
            }`}
            aria-label={`Rate ${star} stars`}
          >
            <Star
              className={`${starSize} transition-colors ${
                isFilled
                  ? "fill-yellow-400 text-yellow-400"
                  : "fill-transparent text-muted-foreground/50"
              }`}
            />
          </button>
        );
      })}
    </div>
  );
};
