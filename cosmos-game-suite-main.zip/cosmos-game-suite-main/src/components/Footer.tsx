import { Link } from "react-router-dom";
import { Gamepad2, Facebook, Instagram, Github, Linkedin } from "lucide-react";
const Footer = () => {
  return <footer className="bg-card border-t mt-16">
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-3">
              <Gamepad2 className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Game Arena
              </span>
            </Link>
            <p className="text-sm text-muted-foreground mb-3">
              Your ultimate destination for classic and modern games. Play, compete, and have fun!
            </p>
            <p className="text-xs text-muted-foreground">
              Game Arena brings you the best collection of browser-based games. From timeless classics like Snake and Tetris to brain-teasing puzzles and fast-paced arcade action, we've got something for every gamer. No downloads, no registration - just pure gaming fun. Challenge yourself, beat your high scores, and become a gaming legend!
            </p>
          </div>

          {/* Contact & Social */}
          <div className="text-right mr-[150px]">
            <h3 className="font-bold mb-3">Connect With Us</h3>
            <div className="space-y-2 text-sm text-muted-foreground mb-4">
              <p>📍 Peshawar , Pakistan </p>
              <p>📞 +44 7300 505787</p>
            </div>
            <div className="flex gap-4 justify-end">
              <a href="https://github.com/Hashirkx04" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125" aria-label="GitHub">
                <Github className="h-5 w-5" />
              </a>
              <a href="https://www.facebook.com/Hashirkx04/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="https://www.instagram.com/hashirkx04/profilecard/?igsh=NTh4d291NXc5bjJx" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="https://www.linkedin.com/in/hashirkx04/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t pt-4 text-center text-sm text-muted-foreground space-y-2">
          <p>&copy; {new Date().getFullYear()} Game Arena. All rights reserved.</p>
          <p>
            Powered by{" "}
            <a href="https://hashirkx04.github.io" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary transition-colors font-semibold underline underline-offset-2">
              Hashirkx04
            </a>
          </p>
        </div>
      </div>
    </footer>;
};
export default Footer;