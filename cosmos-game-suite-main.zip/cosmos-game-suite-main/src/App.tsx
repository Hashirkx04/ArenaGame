import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { ThemeToggle } from "@/components/ThemeToggle";
import GameHub from "./pages/GameHub";
import MemoryGame from "./pages/MemoryGame";
import SnakeGame from "./pages/SnakeGame";
import TicTacToe from "./pages/TicTacToe";
import ColorMatch from "./pages/ColorMatch";
import PuzzleSlider from "./pages/PuzzleSlider";
import SimonSays from "./pages/SimonSays";
import WhackAMole from "./pages/WhackAMole";
import Game2048 from "./pages/Game2048";
import FlappyBird from "./pages/FlappyBird";
import Breakout from "./pages/Breakout";
import Minesweeper from "./pages/Minesweeper";
import WordGuess from "./pages/WordGuess";
import Hangman from "./pages/Hangman";
import Sudoku from "./pages/Sudoku";
import Tetris from "./pages/Tetris";
import Pong from "./pages/Pong";
import RockPaperScissors from "./pages/RockPaperScissors";
import TriviaQuiz from "./pages/TriviaQuiz";
import MathChallenge from "./pages/MathChallenge";
import TypeRacer from "./pages/TypeRacer";
import Platformer from "./pages/Platformer";
import Blackjack from "./pages/Blackjack";
import DiceRoll from "./pages/DiceRoll";
import ConnectFour from "./pages/ConnectFour";
import SpaceInvaders from "./pages/SpaceInvaders";
import Chess from "./pages/Chess";
import ReactionTime from "./pages/ReactionTime";
import TargetShooter from "./pages/TargetShooter";
import StatsDashboard from "./pages/StatsDashboard";
import Leaderboard from "./pages/Leaderboard";
import Achievements from "./pages/Achievements";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <ThemeToggle />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<GameHub />} />
            <Route path="/memory" element={<MemoryGame />} />
            <Route path="/snake" element={<SnakeGame />} />
            <Route path="/tictactoe" element={<TicTacToe />} />
            <Route path="/colormatch" element={<ColorMatch />} />
            <Route path="/puzzle" element={<PuzzleSlider />} />
            <Route path="/simon" element={<SimonSays />} />
            <Route path="/whack" element={<WhackAMole />} />
            <Route path="/2048" element={<Game2048 />} />
            <Route path="/flappy" element={<FlappyBird />} />
            <Route path="/breakout" element={<Breakout />} />
            <Route path="/minesweeper" element={<Minesweeper />} />
            <Route path="/wordguess" element={<WordGuess />} />
            <Route path="/hangman" element={<Hangman />} />
            <Route path="/sudoku" element={<Sudoku />} />
            <Route path="/tetris" element={<Tetris />} />
            <Route path="/pong" element={<Pong />} />
            <Route path="/rps" element={<RockPaperScissors />} />
            <Route path="/trivia" element={<TriviaQuiz />} />
            <Route path="/math" element={<MathChallenge />} />
            <Route path="/typeracer" element={<TypeRacer />} />
            <Route path="/platformer" element={<Platformer />} />
            <Route path="/blackjack" element={<Blackjack />} />
            <Route path="/dice" element={<DiceRoll />} />
            <Route path="/connect4" element={<ConnectFour />} />
            <Route path="/spaceinvaders" element={<SpaceInvaders />} />
            <Route path="/chess" element={<Chess />} />
            <Route path="/reactiontime" element={<ReactionTime />} />
            <Route path="/targetshooter" element={<TargetShooter />} />
            <Route path="/stats" element={<StatsDashboard />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/achievements" element={<Achievements />} />
            <Route path="/profile" element={<Profile />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
