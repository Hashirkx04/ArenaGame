import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

type SudokuGrid = (number | null)[][];

const Sudoku = () => {
  const [grid, setGrid] = useState<SudokuGrid>([]);
  const [solution, setSolution] = useState<SudokuGrid>([]);
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    generatePuzzle();
  }, []);

  const generatePuzzle = () => {
    const newGrid: SudokuGrid = Array(9).fill(null).map(() => Array(9).fill(null));
    const newSolution: SudokuGrid = Array(9).fill(null).map(() => Array(9).fill(0));
    
    // Simple puzzle generation (for demo)
    const puzzle = [
      [5,3,null,null,7,null,null,null,null],
      [6,null,null,1,9,5,null,null,null],
      [null,9,8,null,null,null,null,6,null],
      [8,null,null,null,6,null,null,null,3],
      [4,null,null,8,null,3,null,null,1],
      [7,null,null,null,2,null,null,null,6],
      [null,6,null,null,null,null,2,8,null],
      [null,null,null,4,1,9,null,null,5],
      [null,null,null,null,8,null,null,7,9]
    ];
    
    setGrid(puzzle as SudokuGrid);
    setSolution(puzzle as SudokuGrid);
  };

  const handleNumberClick = (num: number) => {
    if (!selectedCell) return;
    
    const [row, col] = selectedCell;
    const newGrid = grid.map(r => [...r]);
    newGrid[row][col] = num;
    setGrid(newGrid);
  };

  const checkSolution = () => {
    const isComplete = grid.every(row => row.every(cell => cell !== null));
    if (isComplete) {
      toast({ title: "Puzzle Complete!", description: "Great job!" });
    } else {
      toast({ title: "Not Complete", description: "Keep going!", variant: "destructive" });
    }
  };

  return (
    <>
      <Helmet>
        <title>Sudoku - Number Puzzle Game | Game Arena</title>
        <meta name="description" content="Play Sudoku online. Fill the 9x9 grid with numbers and solve this classic logic puzzle game." />
        <meta name="keywords" content="sudoku, sudoku puzzle, number puzzle, logic game, sudoku online" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Sudoku
          </h1>
          <Button onClick={generatePuzzle}>New Game</Button>
        </div>

        <Card className="p-4 mb-6">
          <div className="grid grid-cols-9 gap-1 mb-6">
            {grid.map((row, rowIndex) => 
              row.map((cell, colIndex) => (
                <button
                  key={`${rowIndex}-${colIndex}`}
                  onClick={() => setSelectedCell([rowIndex, colIndex])}
                  className={`w-10 h-10 border flex items-center justify-center font-bold ${
                    selectedCell?.[0] === rowIndex && selectedCell?.[1] === colIndex
                      ? "bg-primary text-primary-foreground"
                      : "bg-card hover:bg-accent"
                  } ${(colIndex + 1) % 3 === 0 ? "border-r-2" : ""} ${(rowIndex + 1) % 3 === 0 ? "border-b-2" : ""}`}
                >
                  {cell}
                </button>
              ))
            )}
          </div>

          <div className="grid grid-cols-9 gap-2">
            {[1,2,3,4,5,6,7,8,9].map(num => (
              <Button
                key={num}
                onClick={() => handleNumberClick(num)}
                variant="outline"
              >
                {num}
              </Button>
            ))}
          </div>
        </Card>

        <div className="text-center">
          <Button onClick={checkSolution} size="lg">Check Solution</Button>
        </div>
      </div>
    </div>
    </>
  );
};

export default Sudoku;
