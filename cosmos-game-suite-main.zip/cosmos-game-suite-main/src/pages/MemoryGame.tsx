import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";

type CardType = {
  id: number;
  value: string;
  isFlipped: boolean;
  isMatched: boolean;
};

const emojis = ["🎮", "🎯", "🎲", "🎪", "🎨", "🎭", "🎸", "🎺"];

const MemoryGame = () => {
  const [cards, setCards] = useState<CardType[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const audio = useGameAudio();

  const initializeGame = () => {
    const gameCards = [...emojis, ...emojis]
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        value: emoji,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(gameCards);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    if (flippedCards.length === 2) {
      setMoves(moves + 1);
      const [first, second] = flippedCards;
      
      if (cards[first].value === cards[second].value) {
        audio.playSuccessSound();
        setCards(cards.map((card, index) => 
          index === first || index === second 
            ? { ...card, isMatched: true }
            : card
        ));
        setMatches(matches + 1);
        setFlippedCards([]);
        
        if (matches + 1 === emojis.length) {
          setTimeout(() => {
            audio.playWinSound();
            toast.success(`Congratulations! You won in ${moves + 1} moves!`);
          }, 500);
        }
      } else {
        setTimeout(() => {
          setCards(cards.map((card, index) =>
            index === first || index === second
              ? { ...card, isFlipped: false }
              : card
          ));
          setFlippedCards([]);
        }, 1000);
      }
    }
  }, [flippedCards]);

  const handleCardClick = (index: number) => {
    if (
      flippedCards.length === 2 ||
      cards[index].isFlipped ||
      cards[index].isMatched ||
      flippedCards.includes(index)
    ) {
      return;
    }

    audio.playClickSound();
    setCards(cards.map((card, i) =>
      i === index ? { ...card, isFlipped: true } : card
    ));
    setFlippedCards([...flippedCards, index]);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Memory Match
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Moves: <span className="text-primary font-bold">{moves}</span></span>
              <span>Matches: <span className="text-secondary font-bold">{matches}/{emojis.length}</span></span>
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={initializeGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="mb-6">
          <AudioControls
            volume={audio.volume}
            isMuted={audio.isMuted}
            onVolumeChange={audio.setVolume}
            onToggleMute={audio.toggleMute}
          />
        </div>

        <div className="grid grid-cols-4 gap-4 max-w-2xl mx-auto">
          {cards.map((card, index) => (
            <Card
              key={card.id}
              onClick={() => handleCardClick(index)}
              className={`aspect-square flex items-center justify-center text-5xl cursor-pointer transition-all duration-300 hover:shadow-game border-border
                ${card.isFlipped || card.isMatched ? 'bg-gradient-to-br from-primary to-secondary' : 'bg-card hover:border-primary'} 
                ${card.isMatched ? 'opacity-50' : ''}`}
            >
              {card.isFlipped || card.isMatched ? card.value : "?"}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MemoryGame;
