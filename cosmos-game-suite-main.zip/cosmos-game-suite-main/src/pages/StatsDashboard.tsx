import { Link } from "react-router-dom";
import { Helmet } from "react-helmet";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useGameStats } from "@/hooks/useGameStats";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { Trophy, Clock, Target, TrendingUp, Home, BarChart3 } from "lucide-react";

const COLORS = ['hsl(189 94% 43%)', 'hsl(280 70% 55%)', 'hsl(330 80% 60%)', 'hsl(189 94% 60%)'];

const gameNames: { [key: string]: string } = {
  memory: "Memory Match",
  snake: "Snake Game",
  tictactoe: "Tic Tac Toe",
  colormatch: "Color Rush",
  puzzle: "Puzzle Slider",
  simon: "Simon Says",
  whack: "Whack-a-Mole",
  "2048": "2048 Challenge",
  flappy: "Flappy Bird",
  breakout: "Breakout",
  minesweeper: "Minesweeper",
  wordguess: "Word Guess",
  hangman: "Hangman",
  sudoku: "Sudoku",
  tetris: "Tetris",
  pong: "Pong",
  rps: "Rock Paper Scissors",
  trivia: "Trivia Quiz",
  math: "Math Challenge",
  typeracer: "Type Racer",
  platformer: "Platform Jumper",
  blackjack: "Blackjack",
  dice: "Dice Roll",
  connect4: "Connect Four",
  spaceinvaders: "Space Invaders",
  chess: "Chess",
  reactiontime: "Reaction Time",
  targetshooter: "Target Shooter",
};

const StatsDashboard = () => {
  const { getAllStats, getTotalStats } = useGameStats();
  const allStats = getAllStats();
  const totalStats = getTotalStats();

  const gamesPlayedData = Object.entries(allStats)
    .filter(([_, stats]) => stats.gamesPlayed > 0)
    .map(([gameId, stats]) => ({
      name: gameNames[gameId] || gameId,
      played: stats.gamesPlayed,
      wins: stats.wins,
      losses: stats.losses,
    }))
    .sort((a, b) => b.played - a.played)
    .slice(0, 10);

  const winRateData = Object.entries(allStats)
    .filter(([_, stats]) => stats.gamesPlayed > 0)
    .map(([gameId, stats]) => ({
      name: gameNames[gameId] || gameId,
      winRate: stats.gamesPlayed > 0 ? Math.round((stats.wins / stats.gamesPlayed) * 100) : 0,
      games: stats.gamesPlayed,
    }))
    .sort((a, b) => b.winRate - a.winRate)
    .slice(0, 8);

  const scoreData = Object.entries(allStats)
    .filter(([_, stats]) => stats.totalScore > 0)
    .map(([gameId, stats]) => ({
      name: gameNames[gameId] || gameId,
      avgScore: Math.round(stats.totalScore / stats.gamesPlayed),
      highScore: stats.highScore,
    }))
    .sort((a, b) => b.highScore - a.highScore)
    .slice(0, 8);

  const timePlayedData = Object.entries(allStats)
    .filter(([_, stats]) => stats.totalTimePlayed > 0)
    .map(([gameId, stats]) => ({
      name: gameNames[gameId] || gameId,
      hours: Math.round((stats.totalTimePlayed / 3600) * 10) / 10,
    }))
    .sort((a, b) => b.hours - a.hours)
    .slice(0, 8);

  const performanceDistribution = [
    { name: 'Wins', value: totalStats.totalWins },
    { name: 'Losses', value: totalStats.totalLosses },
    { name: 'Draws', value: totalStats.totalDraws },
  ].filter(item => item.value > 0);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const overallWinRate = totalStats.totalGamesPlayed > 0 
    ? Math.round((totalStats.totalWins / totalStats.totalGamesPlayed) * 100) 
    : 0;

  return (
    <>
      <Helmet>
        <title>Statistics Dashboard - Game Arena</title>
        <meta name="description" content="View your gaming statistics, win rates, scores, and performance across all games in Game Arena." />
      </Helmet>
      
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        <div className="absolute top-20 left-20 w-64 h-64 bg-primary rounded-full blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: "1s" }} />
        
        {/* Content */}
        <div className="relative z-10 container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary via-secondary to-game-pink bg-clip-text text-transparent">
                Statistics Dashboard
              </h1>
              <p className="text-muted-foreground">Track your gaming performance and achievements</p>
            </div>
            <Link to="/">
              <Button variant="outline" size="lg" className="gap-2">
                <Home className="w-4 h-4" />
                Back to Games
              </Button>
            </Link>
          </div>

          {totalStats.totalGamesPlayed === 0 ? (
            <Card className="bg-gradient-card border-border">
              <CardContent className="py-16 text-center">
                <BarChart3 className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-2xl font-bold mb-2">No Statistics Yet</h3>
                <p className="text-muted-foreground mb-6">Start playing games to see your statistics here!</p>
                <Link to="/">
                  <Button size="lg" className="gap-2">
                    <Home className="w-4 h-4" />
                    Browse Games
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card className="bg-gradient-card border-border hover:border-primary transition-all">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Total Games</CardTitle>
                    <Target className="w-4 h-4 text-primary" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">{totalStats.totalGamesPlayed}</div>
                    <p className="text-xs text-muted-foreground mt-1">Across all games</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-card border-border hover:border-secondary transition-all">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Win Rate</CardTitle>
                    <Trophy className="w-4 h-4 text-secondary" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">{overallWinRate}%</div>
                    <p className="text-xs text-muted-foreground mt-1">{totalStats.totalWins} wins total</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-card border-border hover:border-game-pink transition-all">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Total Score</CardTitle>
                    <TrendingUp className="w-4 h-4 text-game-pink" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">{totalStats.totalScore.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground mt-1">Points earned</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-card border-border hover:border-game-glow transition-all">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">Time Played</CardTitle>
                    <Clock className="w-4 h-4 text-game-glow" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-foreground">{formatTime(totalStats.totalTimePlayed)}</div>
                    <p className="text-xs text-muted-foreground mt-1">Gaming time</p>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Games Played Chart */}
                {gamesPlayedData.length > 0 && (
                  <Card className="bg-gradient-card border-border">
                    <CardHeader>
                      <CardTitle className="text-foreground">Most Played Games</CardTitle>
                      <CardDescription>Number of games played by title</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={gamesPlayedData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} angle={-45} textAnchor="end" height={100} />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                            labelStyle={{ color: 'hsl(var(--foreground))' }}
                          />
                          <Bar dataKey="played" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}

                {/* Win Rate Chart */}
                {winRateData.length > 0 && (
                  <Card className="bg-gradient-card border-border">
                    <CardHeader>
                      <CardTitle className="text-foreground">Win Rate by Game</CardTitle>
                      <CardDescription>Percentage of games won</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={winRateData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} angle={-45} textAnchor="end" height={100} />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                            labelStyle={{ color: 'hsl(var(--foreground))' }}
                          />
                          <Bar dataKey="winRate" fill="hsl(var(--secondary))" radius={[8, 8, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}

                {/* Performance Distribution */}
                {performanceDistribution.length > 0 && (
                  <Card className="bg-gradient-card border-border">
                    <CardHeader>
                      <CardTitle className="text-foreground">Performance Distribution</CardTitle>
                      <CardDescription>Wins, losses, and draws breakdown</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={performanceDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="hsl(var(--primary))"
                            dataKey="value"
                          >
                            {performanceDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}

                {/* Time Played Chart */}
                {timePlayedData.length > 0 && (
                  <Card className="bg-gradient-card border-border">
                    <CardHeader>
                      <CardTitle className="text-foreground">Time Played</CardTitle>
                      <CardDescription>Hours spent on each game</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={timePlayedData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} angle={-45} textAnchor="end" height={100} />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                            labelStyle={{ color: 'hsl(var(--foreground))' }}
                          />
                          <Line type="monotone" dataKey="hours" stroke="hsl(var(--game-pink))" strokeWidth={3} dot={{ fill: 'hsl(var(--game-pink))' }} />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}

                {/* High Scores Chart */}
                {scoreData.length > 0 && (
                  <Card className="bg-gradient-card border-border lg:col-span-2">
                    <CardHeader>
                      <CardTitle className="text-foreground">Score Comparison</CardTitle>
                      <CardDescription>Average scores vs high scores</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={scoreData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} angle={-45} textAnchor="end" height={100} />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                            labelStyle={{ color: 'hsl(var(--foreground))' }}
                          />
                          <Legend />
                          <Bar dataKey="avgScore" fill="hsl(var(--game-glow))" radius={[8, 8, 0, 0]} name="Average Score" />
                          <Bar dataKey="highScore" fill="hsl(var(--game-purple))" radius={[8, 8, 0, 0]} name="High Score" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default StatsDashboard;
