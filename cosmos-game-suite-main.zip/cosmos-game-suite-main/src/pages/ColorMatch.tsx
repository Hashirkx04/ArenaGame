import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw, Play } from "lucide-react";
import { toast } from "sonner";

const colors = [
  { name: "Cyan", bg: "hsl(189, 94%, 43%)", value: "cyan" },
  { name: "Purple", bg: "hsl(280, 70%, 55%)", value: "purple" },
  { name: "Pink", bg: "hsl(330, 80%, 60%)", value: "pink" },
  { name: "Green", bg: "hsl(142, 76%, 36%)", value: "green" },
];

const ColorMatch = () => {
  const [targetColor, setTargetColor] = useState(colors[0]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [feedback, setFeedback] = useState("");

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setIsPlaying(true);
    setFeedback("");
    generateNewColor();
  };

  const generateNewColor = () => {
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setTargetColor(randomColor);
  };

  const handleColorClick = (clickedColor: typeof colors[0]) => {
    if (!isPlaying) return;

    if (clickedColor.value === targetColor.value) {
      setScore(score + 10);
      setFeedback("✓ Correct!");
      setTimeout(() => setFeedback(""), 500);
      generateNewColor();
    } else {
      setScore(Math.max(0, score - 5));
      setFeedback("✗ Wrong!");
      setTimeout(() => setFeedback(""), 500);
    }
  };

  useEffect(() => {
    if (!isPlaying || timeLeft <= 0) {
      if (timeLeft === 0) {
        setIsPlaying(false);
        if (score > highScore) {
          setHighScore(score);
          toast.success(`New High Score: ${score}!`);
        } else {
          toast(`Game Over! Score: ${score}`);
        }
      }
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, timeLeft, score, highScore]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Color Rush
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>High Score: <span className="text-secondary font-bold">{highScore}</span></span>
              <span>Time: <span className="text-game-pink font-bold">{timeLeft}s</span></span>
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            {isPlaying ? <RotateCcw className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>
        </div>

        <div className="max-w-2xl mx-auto space-y-8">
          {!isPlaying && timeLeft === 30 ? (
            <Card className="p-12 text-center bg-gradient-card border-border">
              <h2 className="text-2xl font-bold mb-4">How to Play</h2>
              <p className="text-muted-foreground mb-6">
                Click the color that matches the name shown. You have 30 seconds to score as many points as possible!
              </p>
              <Button onClick={startGame} className="bg-primary hover:bg-primary/90">
                Start Game
              </Button>
            </Card>
          ) : (
            <>
              <Card className="p-12 text-center bg-gradient-card border-border relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-2 bg-muted">
                  <div 
                    className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-1000"
                    style={{ width: `${(timeLeft / 30) * 100}%` }}
                  />
                </div>
                
                <h2 className="text-6xl font-bold mb-4" style={{ color: targetColor.bg }}>
                  {targetColor.name}
                </h2>
                
                {feedback && (
                  <p className={`text-2xl font-bold ${feedback.includes('✓') ? 'text-green-500' : 'text-red-500'}`}>
                    {feedback}
                  </p>
                )}
              </Card>

              <div className="grid grid-cols-2 gap-4">
                {colors.map((color) => (
                  <Card
                    key={color.value}
                    onClick={() => handleColorClick(color)}
                    className="aspect-square flex items-center justify-center cursor-pointer transition-all duration-300 hover:shadow-game-hover hover:scale-105 border-2 border-border hover:border-primary"
                    style={{ backgroundColor: color.bg }}
                  >
                    <span className="text-3xl font-bold text-white drop-shadow-lg">
                      {color.name}
                    </span>
                  </Card>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ColorMatch;
