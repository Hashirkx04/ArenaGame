import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

const MathChallenge = () => {
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [operator, setOperator] = useState("+");
  const [answer, setAnswer] = useState("");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [isPlaying, setIsPlaying] = useState(false);
  const [highScore, setHighScore] = useState(0);
  const { toast } = useToast();

  const generateQuestion = () => {
    const operators = ["+", "-", "×", "÷"];
    const op = operators[Math.floor(Math.random() * operators.length)];
    setOperator(op);

    if (op === "÷") {
      const divisor = Math.floor(Math.random() * 10) + 1;
      const quotient = Math.floor(Math.random() * 10) + 1;
      setNum1(divisor * quotient);
      setNum2(divisor);
    } else {
      setNum1(Math.floor(Math.random() * 50) + 1);
      setNum2(Math.floor(Math.random() * 50) + 1);
    }
    setAnswer("");
  };

  const startGame = () => {
    setScore(0);
    setTimeLeft(60);
    setIsPlaying(true);
    generateQuestion();
  };

  useEffect(() => {
    if (isPlaying && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setIsPlaying(false);
      if (score > highScore) {
        setHighScore(score);
        toast({ title: "New High Score!", description: `${score} correct answers!` });
      }
    }
  }, [timeLeft, isPlaying]);

  const checkAnswer = () => {
    let correct = 0;
    switch (operator) {
      case "+": correct = num1 + num2; break;
      case "-": correct = num1 - num2; break;
      case "×": correct = num1 * num2; break;
      case "÷": correct = num1 / num2; break;
    }

    if (parseInt(answer) === correct) {
      setScore(score + 1);
      toast({ title: "Correct!", description: "+1 point" });
      generateQuestion();
    } else {
      toast({ title: "Wrong!", description: `Correct answer was ${correct}`, variant: "destructive" });
      setAnswer("");
    }
  };

  return (
    <>
      <Helmet>
        <title>Math Challenge - Speed Math Game | Game Arena</title>
        <meta name="description" content="Test your math skills with our Math Challenge. Solve problems quickly and improve your calculation speed!" />
        <meta name="keywords" content="math challenge, math game, speed math, mental math, arithmetic game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Math Challenge
          </h1>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">High Score</div>
            <div className="text-2xl font-bold">{highScore}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">Score</div>
            <div className="text-4xl text-primary">{score}</div>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">Time</div>
            <div className="text-4xl text-secondary">{timeLeft}s</div>
          </Card>
        </div>

        {!isPlaying ? (
          <Card className="p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Math Speed Test</h2>
            <p className="text-muted-foreground mb-8">Solve as many problems as you can in 60 seconds!</p>
            <Button onClick={startGame} size="lg">Start Challenge</Button>
          </Card>
        ) : (
          <Card className="p-8">
            <div className="text-center mb-8">
              <div className="text-6xl font-bold mb-4">
                {num1} {operator} {num2} = ?
              </div>
            </div>
            
            <div className="flex gap-4">
              <Input
                type="number"
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && checkAnswer()}
                placeholder="Your answer"
                className="text-2xl text-center h-16"
                autoFocus
              />
              <Button onClick={checkAnswer} size="lg" className="px-8">
                Submit
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
    </>
  );
};

export default MathChallenge;
