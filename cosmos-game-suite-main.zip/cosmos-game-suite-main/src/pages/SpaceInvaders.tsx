import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Helmet } from "react-helmet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const SpaceInvaders = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [highScore, setHighScore] = useState(0);
  const [showWinDialog, setShowWinDialog] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let playerX = 375;
    const playerY = 550;
    const playerWidth = 50;
    const playerHeight = 30;

    const invaders: any[] = [];
    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 8; col++) {
        invaders.push({
          x: col * 80 + 50,
          y: row * 60 + 50,
          width: 40,
          height: 30,
          alive: true
        });
      }
    }

    const bullets: any[] = [];
    let currentScore = 0;

    const drawPlayer = () => {
      ctx.fillStyle = "#fff";
      ctx.fillRect(playerX, playerY, playerWidth, playerHeight);
    };

    const drawInvaders = () => {
      invaders.forEach(inv => {
        if (inv.alive) {
          ctx.fillStyle = "#0f0";
          ctx.fillRect(inv.x, inv.y, inv.width, inv.height);
        }
      });
    };

    const drawBullets = () => {
      bullets.forEach(bullet => {
        ctx.fillStyle = "#ff0";
        ctx.fillRect(bullet.x, bullet.y, 4, 10);
      });
    };

    const update = () => {
      bullets.forEach((bullet, index) => {
        bullet.y -= 5;
        if (bullet.y < 0) bullets.splice(index, 1);

        invaders.forEach(inv => {
          if (inv.alive &&
              bullet.x > inv.x &&
              bullet.x < inv.x + inv.width &&
              bullet.y > inv.y &&
              bullet.y < inv.y + inv.height) {
            inv.alive = false;
            bullets.splice(index, 1);
            currentScore += 10;
            setScore(currentScore);
          }
        });
      });

      // Check for win condition
      const allDestroyed = invaders.every(inv => !inv.alive);
      if (allDestroyed) {
        setIsPlaying(false);
        setShowWinDialog(true);
        if (currentScore > highScore) setHighScore(currentScore);
      }
    };

    const render = () => {
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, 800, 600);
      drawPlayer();
      drawInvaders();
      drawBullets();
    };

    const gameLoop = () => {
      update();
      render();
      requestAnimationFrame(gameLoop);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" && playerX > 0) playerX -= 15;
      if (e.key === "ArrowRight" && playerX < 750) playerX += 15;
      if (e.key === " ") {
        bullets.push({ x: playerX + playerWidth / 2, y: playerY });
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    gameLoop();

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      if (currentScore > highScore) setHighScore(currentScore);
    };
  }, [isPlaying]);

  return (
    <>
      <Helmet>
        <title>Space Invaders - Classic Arcade Shooter | Game Arena</title>
        <meta name="description" content="Play Space Invaders online. Defend Earth from alien invaders in this classic arcade shooter game!" />
        <meta name="keywords" content="space invaders, arcade game, shooter game, retro game, aliens game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Space Invaders
          </h1>
          <div className="text-right">
            <div className="text-2xl font-bold">Score: {score}</div>
            <div className="text-sm text-muted-foreground">High: {highScore}</div>
          </div>
        </div>

        <Card className="p-4">
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            className="w-full border rounded"
          />
        </Card>

        <div className="text-center mt-6">
          {!isPlaying ? (
            <Button onClick={() => { setIsPlaying(true); setScore(0); }} size="lg">
              Start Game
            </Button>
          ) : (
            <div className="text-muted-foreground">
              Use Arrow Keys to Move, Spacebar to Shoot
            </div>
          )}
        </div>
      </div>
    </div>

    <Dialog open={showWinDialog} onOpenChange={setShowWinDialog}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-2xl">🎉 Mission Complete!</DialogTitle>
          <DialogDescription className="text-lg">
            You destroyed all the invaders! Final Score: {score}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex gap-2">
          <Link to="/">
            <Button variant="outline">Exit</Button>
          </Link>
          <Button onClick={() => { setShowWinDialog(false); setIsPlaying(true); setScore(0); }}>
            Play Again
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
    </>
  );
};

export default SpaceInvaders;
