import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Helmet } from "react-helmet";
import { ArrowLeft, User, Trophy, Gamepad2, Star, Heart, Clock, Target, Award, TrendingUp } from "lucide-react";
import { useAchievements, achievements } from "@/hooks/useAchievements";
import { useGameStats } from "@/hooks/useGameStats";
import { useLeaderboard } from "@/hooks/useLeaderboard";
import { useGameFavorites } from "@/hooks/useGameFavorites";
import { useGameRatings } from "@/hooks/useGameRatings";
import { useRecentGames } from "@/hooks/useRecentGames";

const games = [
  { id: "memory", title: "Memory Match" },
  { id: "snake", title: "Snake Game" },
  { id: "tictactoe", title: "Tic Tac Toe" },
  { id: "colormatch", title: "Color Rush" },
  { id: "puzzle", title: "Puzzle Slider" },
  { id: "simon", title: "Simon Says" },
  { id: "whack", title: "Whack-a-Mole" },
  { id: "2048", title: "2048 Challenge" },
  { id: "flappy", title: "Flappy Bird" },
  { id: "breakout", title: "Breakout" },
  { id: "minesweeper", title: "Minesweeper" },
  { id: "wordguess", title: "Word Guess" },
  { id: "hangman", title: "Hangman" },
  { id: "sudoku", title: "Sudoku" },
  { id: "tetris", title: "Tetris" },
  { id: "pong", title: "Pong" },
  { id: "rps", title: "Rock Paper Scissors" },
  { id: "trivia", title: "Trivia Quiz" },
  { id: "math", title: "Math Challenge" },
  { id: "typeracer", title: "Type Racer" },
  { id: "platformer", title: "Platform Jumper" },
  { id: "blackjack", title: "Blackjack" },
  { id: "dice", title: "Dice Roll" },
  { id: "connect4", title: "Connect Four" },
  { id: "spaceinvaders", title: "Space Invaders" },
  { id: "chess", title: "Chess" },
  { id: "reactiontime", title: "Reaction Time" },
  { id: "targetshooter", title: "Target Shooter" },
];

const Profile = () => {
  const { unlockedAchievements, progress } = useAchievements();
  const { getTotalStats, getAllStats } = useGameStats();
  const { getAllTopScores } = useLeaderboard();
  const { favorites } = useGameFavorites();
  const { getRating } = useGameRatings();
  const { recentGames } = useRecentGames();

  const totalStats = getTotalStats();
  const allStats = getAllStats();
  const allTopScores = getAllTopScores();
  
  const achievementProgress = (unlockedAchievements.length / achievements.length) * 100;
  const gamesExplored = progress.uniqueGamesPlayed.length;
  const totalGames = 28;
  const explorationProgress = (gamesExplored / totalGames) * 100;

  // Calculate total high scores across all games
  const totalHighScores = allTopScores.length;

  // Get games with ratings
  const ratedGames = games.filter(game => getRating(game.id) > 0);

  // Format time played
  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  };

  // Get recent unlocked achievements (last 5)
  const recentAchievements = [...unlockedAchievements]
    .sort((a, b) => new Date(b.unlockedAt).getTime() - new Date(a.unlockedAt).getTime())
    .slice(0, 5)
    .map(ua => achievements.find(a => a.id === ua.id))
    .filter(Boolean);

  // Get top performing games
  const topGames = Object.entries(allStats)
    .map(([gameId, stats]) => ({
      id: gameId,
      title: games.find(g => g.id === gameId)?.title || gameId,
      ...stats
    }))
    .sort((a, b) => b.highScore - a.highScore)
    .slice(0, 5);

  return (
    <>
      <Helmet>
        <title>Player Profile - Game Arena</title>
        <meta name="description" content="View your gaming profile with stats, achievements, and game history." />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        <div className="absolute top-20 left-20 w-64 h-64 bg-primary rounded-full blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: "1s" }} />

        <div className="relative z-10 container mx-auto px-4 py-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Link to="/">
              <Button variant="ghost" size="icon" className="hover:bg-primary/20">
                <ArrowLeft className="h-6 w-6" />
              </Button>
            </Link>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-secondary to-game-pink bg-clip-text text-transparent">
                Player Profile
              </h1>
              <p className="text-muted-foreground">Your gaming journey at a glance</p>
            </div>
          </div>

          {/* Main Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="p-4 bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-gradient-to-br from-primary to-secondary">
                  <Gamepad2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{totalStats.totalGamesPlayed}</p>
                  <p className="text-xs text-muted-foreground">Games Played</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-gradient-to-br from-yellow-500 to-yellow-600">
                  <Trophy className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{totalStats.totalWins}</p>
                  <p className="text-xs text-muted-foreground">Total Wins</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-gradient-to-br from-game-pink to-game-purple">
                  <Award className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{unlockedAchievements.length}</p>
                  <p className="text-xs text-muted-foreground">Achievements</p>
                </div>
              </div>
            </Card>

            <Card className="p-4 bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-gradient-to-br from-green-500 to-green-600">
                  <Target className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{gamesExplored}</p>
                  <p className="text-xs text-muted-foreground">Games Explored</p>
                </div>
              </div>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Progress & Stats */}
            <div className="lg:col-span-2 space-y-6">
              {/* Progress Cards */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Progress Overview
                </h2>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Achievement Progress</span>
                      <span className="text-foreground font-medium">{unlockedAchievements.length}/{achievements.length}</span>
                    </div>
                    <Progress value={achievementProgress} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Games Explored</span>
                      <span className="text-foreground font-medium">{gamesExplored}/{totalGames}</span>
                    </div>
                    <Progress value={explorationProgress} className="h-2" />
                  </div>
                </div>
              </Card>

              {/* Detailed Stats */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4">Detailed Statistics</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-primary">{totalStats.totalScore.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Total Score</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-green-500">{totalStats.totalWins}</p>
                    <p className="text-sm text-muted-foreground">Wins</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-red-500">{totalStats.totalLosses}</p>
                    <p className="text-sm text-muted-foreground">Losses</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-yellow-500">{totalStats.totalDraws}</p>
                    <p className="text-sm text-muted-foreground">Draws</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-secondary">{formatTime(totalStats.totalTimePlayed)}</p>
                    <p className="text-sm text-muted-foreground">Time Played</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-background/50">
                    <p className="text-2xl font-bold text-game-pink">{totalHighScores}</p>
                    <p className="text-sm text-muted-foreground">High Scores</p>
                  </div>
                </div>
              </Card>

              {/* Top Games */}
              {topGames.length > 0 && (
                <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                  <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    Top Performing Games
                  </h2>
                  <div className="space-y-3">
                    {topGames.map((game, index) => (
                      <div key={game.id} className="flex items-center justify-between p-3 rounded-lg bg-background/50 hover:bg-background/70 transition-colors">
                        <div className="flex items-center gap-3">
                          <span className={`text-lg font-bold ${index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-400' : index === 2 ? 'text-amber-600' : 'text-muted-foreground'}`}>
                            #{index + 1}
                          </span>
                          <span className="font-medium text-foreground">{game.title}</span>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-primary">{game.highScore.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">{game.gamesPlayed} plays</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>

            {/* Right Column - Quick Info */}
            <div className="space-y-6">
              {/* Favorites */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Favorite Games
                </h2>
                {favorites.length > 0 ? (
                  <div className="space-y-2">
                    {favorites.slice(0, 5).map(gameId => {
                      const game = games.find(g => g.id === gameId);
                      return game ? (
                        <Link key={gameId} to={`/${gameId === 'memory' ? 'memory' : gameId}`}>
                          <div className="p-3 rounded-lg bg-background/50 hover:bg-background/70 transition-colors cursor-pointer">
                            <p className="font-medium text-foreground">{game.title}</p>
                          </div>
                        </Link>
                      ) : null;
                    })}
                    {favorites.length > 5 && (
                      <p className="text-sm text-muted-foreground text-center">+{favorites.length - 5} more</p>
                    )}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No favorites yet. Heart a game to add it!</p>
                )}
              </Card>

              {/* Recent Achievements */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Award className="h-5 w-5 text-game-pink" />
                  Recent Achievements
                </h2>
                {recentAchievements.length > 0 ? (
                  <div className="space-y-2">
                    {recentAchievements.map(achievement => achievement && (
                      <div key={achievement.id} className="flex items-center gap-3 p-3 rounded-lg bg-background/50">
                        <span className="text-2xl">{achievement.icon}</span>
                        <div>
                          <p className="font-medium text-foreground text-sm">{achievement.title}</p>
                          <p className="text-xs text-muted-foreground">{achievement.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No achievements yet. Start playing to unlock them!</p>
                )}
                <Link to="/achievements">
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    View All Achievements
                  </Button>
                </Link>
              </Card>

              {/* Recently Played */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5 text-secondary" />
                  Recently Played
                </h2>
                {recentGames.length > 0 ? (
                  <div className="space-y-2">
                    {recentGames.map(gameId => {
                      const game = games.find(g => g.id === gameId);
                      return game ? (
                        <Link key={gameId} to={`/${gameId === 'memory' ? 'memory' : gameId}`}>
                          <div className="p-3 rounded-lg bg-background/50 hover:bg-background/70 transition-colors cursor-pointer">
                            <p className="font-medium text-foreground">{game.title}</p>
                          </div>
                        </Link>
                      ) : null;
                    })}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-sm">No recent games. Start playing!</p>
                )}
              </Card>

              {/* Quick Actions */}
              <Card className="p-6 bg-card/50 backdrop-blur-sm border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-4">Quick Actions</h2>
                <div className="space-y-2">
                  <Link to="/leaderboard">
                    <Button variant="outline" className="w-full justify-start gap-2">
                      <Trophy className="h-4 w-4" />
                      View Leaderboard
                    </Button>
                  </Link>
                  <Link to="/stats">
                    <Button variant="outline" className="w-full justify-start gap-2">
                      <TrendingUp className="h-4 w-4" />
                      View Full Stats
                    </Button>
                  </Link>
                  <Link to="/">
                    <Button variant="outline" className="w-full justify-start gap-2">
                      <Gamepad2 className="h-4 w-4" />
                      Browse Games
                    </Button>
                  </Link>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
