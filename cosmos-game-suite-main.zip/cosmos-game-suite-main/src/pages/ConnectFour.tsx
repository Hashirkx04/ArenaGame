import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

type Cell = 0 | 1 | 2;
type Board = Cell[][];

const ConnectFour = () => {
  const [board, setBoard] = useState<Board>(
    Array(6).fill(null).map(() => Array(7).fill(0))
  );
  const [currentPlayer, setCurrentPlayer] = useState<1 | 2>(1);
  const [winner, setWinner] = useState<number | null>(null);
  const { toast } = useToast();

  const checkWinner = (board: Board, row: number, col: number, player: number): boolean => {
    const directions = [
      [0, 1], [1, 0], [1, 1], [1, -1]
    ];

    for (const [dr, dc] of directions) {
      let count = 1;
      
      for (let i = 1; i < 4; i++) {
        const r = row + dr * i;
        const c = col + dc * i;
        if (r >= 0 && r < 6 && c >= 0 && c < 7 && board[r][c] === player) {
          count++;
        } else break;
      }
      
      for (let i = 1; i < 4; i++) {
        const r = row - dr * i;
        const c = col - dc * i;
        if (r >= 0 && r < 6 && c >= 0 && c < 7 && board[r][c] === player) {
          count++;
        } else break;
      }
      
      if (count >= 4) return true;
    }
    
    return false;
  };

  const dropDisc = (col: number) => {
    if (winner) return;
    
    for (let row = 5; row >= 0; row--) {
      if (board[row][col] === 0) {
        const newBoard = board.map(r => [...r]);
        newBoard[row][col] = currentPlayer;
        setBoard(newBoard);
        
        if (checkWinner(newBoard, row, col, currentPlayer)) {
          setWinner(currentPlayer);
          toast({ title: `Player ${currentPlayer} Wins!`, description: "Congratulations!" });
        } else {
          setCurrentPlayer(currentPlayer === 1 ? 2 : 1);
        }
        break;
      }
    }
  };

  const resetGame = () => {
    setBoard(Array(6).fill(null).map(() => Array(7).fill(0)));
    setCurrentPlayer(1);
    setWinner(null);
  };

  const getCellColor = (cell: Cell) => {
    if (cell === 1) return "bg-primary";
    if (cell === 2) return "bg-secondary";
    return "bg-card";
  };

  return (
    <>
      <Helmet>
        <title>Connect Four - Strategy Game | Game Arena</title>
        <meta name="description" content="Play Connect Four online. Drop discs and connect four in a row to win in this classic two-player strategy game." />
        <meta name="keywords" content="connect four, connect 4, four in a row, strategy game, two player game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Connect Four
          </h1>
          <Button onClick={resetGame}>Reset</Button>
        </div>

        <Card className="p-6 mb-6">
          <div className="text-center mb-4">
            {winner ? (
              <div className="text-3xl font-bold">Player {winner} Wins! 🎉</div>
            ) : (
              <div className="text-2xl font-bold">
                Player {currentPlayer}'s Turn
              </div>
            )}
          </div>

          <div className="inline-block p-4 bg-primary/10 rounded-lg">
            {board.map((row, rowIndex) => (
              <div key={rowIndex} className="flex gap-2">
                {row.map((cell, colIndex) => (
                  <button
                    key={colIndex}
                    onClick={() => dropDisc(colIndex)}
                    disabled={winner !== null}
                    className={`w-12 h-12 rounded-full ${getCellColor(cell)} border-2 border-border hover:scale-110 transition-transform`}
                  />
                ))}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
    </>
  );
};

export default ConnectFour;
