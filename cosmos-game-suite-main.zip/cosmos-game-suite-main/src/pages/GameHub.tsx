import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Helmet } from "react-helmet";
import Footer from "@/components/Footer";
import BackToTop from "@/components/BackToTop";
import { Input } from "@/components/ui/input";
import { Gamepad2, Brain, Zap, Grid3x3, Puzzle, Volume2, Hammer, SquareStack, Bird, Blocks, Spade, MessageSquareText, Type, Dices, Circle, Swords, Trophy, BookOpen, Calculator, Target, Clock, Crosshair, BarChart3, Loader2, Search, Heart, ArrowUpDown, History, Award, User } from "lucide-react";
import { useGameFavorites } from "@/hooks/useGameFavorites";
import { useRecentGames } from "@/hooks/useRecentGames";
import { useGameRatings } from "@/hooks/useGameRatings";
import { useAchievements } from "@/hooks/useAchievements";
import { StarRating } from "@/components/StarRating";
import { AchievementToast } from "@/components/AchievementToast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type Category = "all" | "favorites" | "arcade" | "puzzle" | "strategy" | "action" | "card" | "word";
type SortOption = "default" | "a-z" | "z-a" | "popularity" | "newest";

const categories: { id: Category; label: string; icon?: typeof Heart }[] = [
  { id: "all", label: "All Games" },
  { id: "favorites", label: "Favorites", icon: Heart },
  { id: "arcade", label: "Arcade" },
  { id: "puzzle", label: "Puzzle" },
  { id: "strategy", label: "Strategy" },
  { id: "action", label: "Action" },
  { id: "card", label: "Card & Casino" },
  { id: "word", label: "Word & Trivia" },
];

const sortOptions: { id: SortOption; label: string }[] = [
  { id: "default", label: "Default" },
  { id: "a-z", label: "A-Z" },
  { id: "z-a", label: "Z-A" },
  { id: "popularity", label: "Most Popular" },
  { id: "newest", label: "Recently Added" },
];

const games = [
  {
    id: "memory",
    title: "Memory Match",
    description: "Test your memory with matching cards",
    icon: Brain,
    color: "from-primary to-game-glow",
    path: "/memory",
    category: "puzzle" as Category,
    popularity: 85,
    order: 1,
  },
  {
    id: "snake",
    title: "Snake Game",
    description: "Classic snake with modern twist",
    icon: Gamepad2,
    color: "from-secondary to-game-purple",
    path: "/snake",
    category: "arcade" as Category,
    popularity: 95,
    order: 2,
  },
  {
    id: "tictactoe",
    title: "Tic Tac Toe",
    description: "Challenge a friend or AI",
    icon: Grid3x3,
    color: "from-game-pink to-secondary",
    path: "/tictactoe",
    category: "strategy" as Category,
    popularity: 88,
    order: 3,
  },
  {
    id: "colormatch",
    title: "Color Rush",
    description: "Quick reaction color matching",
    icon: Zap,
    color: "from-game-glow to-game-pink",
    path: "/colormatch",
    category: "action" as Category,
    popularity: 72,
    order: 4,
  },
  {
    id: "puzzle",
    title: "Puzzle Slider",
    description: "Slide tiles to complete the picture",
    icon: Puzzle,
    color: "from-game-purple to-primary",
    path: "/puzzle",
    category: "puzzle" as Category,
    popularity: 68,
    order: 5,
  },
  {
    id: "simon",
    title: "Simon Says",
    description: "Remember the sequence of sounds",
    icon: Volume2,
    color: "from-game-pink to-game-glow",
    path: "/simon",
    category: "puzzle" as Category,
    popularity: 75,
    order: 6,
  },
  {
    id: "whack",
    title: "Whack-a-Mole",
    description: "Test your reflexes and speed",
    icon: Hammer,
    color: "from-primary to-game-pink",
    path: "/whack",
    category: "action" as Category,
    popularity: 82,
    order: 7,
  },
  {
    id: "2048",
    title: "2048 Challenge",
    description: "Merge tiles to reach 2048",
    icon: SquareStack,
    color: "from-secondary to-game-glow",
    path: "/2048",
    category: "puzzle" as Category,
    popularity: 90,
    order: 8,
  },
  {
    id: "flappy",
    title: "Flappy Bird",
    description: "Navigate through pipes",
    icon: Bird,
    color: "from-game-glow to-secondary",
    path: "/flappy",
    category: "arcade" as Category,
    popularity: 92,
    order: 9,
  },
  {
    id: "breakout",
    title: "Breakout",
    description: "Break all the bricks",
    icon: Blocks,
    color: "from-game-pink to-primary",
    path: "/breakout",
    category: "arcade" as Category,
    popularity: 78,
    order: 10,
  },
  {
    id: "minesweeper",
    title: "Minesweeper",
    description: "Find all the mines",
    icon: Spade,
    color: "from-primary to-secondary",
    path: "/minesweeper",
    category: "puzzle" as Category,
    popularity: 80,
    order: 11,
  },
  {
    id: "wordguess",
    title: "Word Guess",
    description: "Guess the 5-letter word",
    icon: MessageSquareText,
    color: "from-game-purple to-game-pink",
    path: "/wordguess",
    category: "word" as Category,
    popularity: 87,
    order: 12,
  },
  {
    id: "hangman",
    title: "Hangman",
    description: "Classic word guessing game",
    icon: Type,
    color: "from-secondary to-game-glow",
    path: "/hangman",
    category: "word" as Category,
    popularity: 74,
    order: 13,
  },
  {
    id: "sudoku",
    title: "Sudoku",
    description: "Number puzzle challenge",
    icon: Grid3x3,
    color: "from-game-glow to-primary",
    path: "/sudoku",
    category: "puzzle" as Category,
    popularity: 86,
    order: 14,
  },
  {
    id: "tetris",
    title: "Tetris",
    description: "Classic falling blocks",
    icon: Blocks,
    color: "from-primary to-game-purple",
    path: "/tetris",
    category: "arcade" as Category,
    popularity: 98,
    order: 15,
  },
  {
    id: "pong",
    title: "Pong",
    description: "Classic arcade paddle game",
    icon: Circle,
    color: "from-game-pink to-secondary",
    path: "/pong",
    category: "arcade" as Category,
    popularity: 76,
    order: 16,
  },
  {
    id: "rps",
    title: "Rock Paper Scissors",
    description: "Challenge the AI",
    icon: Target,
    color: "from-game-purple to-game-glow",
    path: "/rps",
    category: "action" as Category,
    popularity: 70,
    order: 17,
  },
  {
    id: "trivia",
    title: "Trivia Quiz",
    description: "Test your knowledge",
    icon: BookOpen,
    color: "from-secondary to-game-pink",
    path: "/trivia",
    category: "word" as Category,
    popularity: 83,
    order: 18,
  },
  {
    id: "math",
    title: "Math Challenge",
    description: "Speed math competition",
    icon: Calculator,
    color: "from-game-glow to-game-purple",
    path: "/math",
    category: "puzzle" as Category,
    popularity: 71,
    order: 19,
  },
  {
    id: "typeracer",
    title: "Type Racer",
    description: "Test your typing speed",
    icon: Type,
    color: "from-primary to-secondary",
    path: "/typeracer",
    category: "action" as Category,
    popularity: 79,
    order: 20,
  },
  {
    id: "platformer",
    title: "Platform Jumper",
    description: "Jump and collect coins",
    icon: Target,
    color: "from-game-pink to-game-glow",
    path: "/platformer",
    category: "arcade" as Category,
    popularity: 77,
    order: 21,
  },
  {
    id: "blackjack",
    title: "Blackjack",
    description: "Beat the dealer",
    icon: Trophy,
    color: "from-secondary to-primary",
    path: "/blackjack",
    category: "card" as Category,
    popularity: 84,
    order: 22,
  },
  {
    id: "dice",
    title: "Dice Roll",
    description: "Roll the dice",
    icon: Dices,
    color: "from-game-purple to-secondary",
    path: "/dice",
    category: "card" as Category,
    popularity: 65,
    order: 23,
  },
  {
    id: "connect4",
    title: "Connect Four",
    description: "Four in a row wins",
    icon: Grid3x3,
    color: "from-game-glow to-game-pink",
    path: "/connect4",
    category: "strategy" as Category,
    popularity: 81,
    order: 24,
  },
  {
    id: "spaceinvaders",
    title: "Space Invaders",
    description: "Defend against aliens",
    icon: Target,
    color: "from-primary to-game-glow",
    path: "/spaceinvaders",
    category: "arcade" as Category,
    popularity: 89,
    order: 25,
  },
  {
    id: "chess",
    title: "Chess",
    description: "Strategic board game",
    icon: Swords,
    color: "from-game-pink to-primary",
    path: "/chess",
    category: "strategy" as Category,
    popularity: 93,
    order: 26,
  },
  {
    id: "reactiontime",
    title: "Reaction Time",
    description: "Test your reflexes",
    icon: Clock,
    color: "from-game-glow to-game-purple",
    path: "/reactiontime",
    category: "action" as Category,
    popularity: 73,
    order: 27,
  },
  {
    id: "targetshooter",
    title: "Target Shooter",
    description: "Hit the moving targets",
    icon: Crosshair,
    color: "from-secondary to-game-pink",
    path: "/targetshooter",
    category: "action" as Category,
    popularity: 80,
    order: 28,
  },
];

const GameHub = () => {
  const [showAllGames, setShowAllGames] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category>("all");
  const [sortBy, setSortBy] = useState<SortOption>("default");
  const { favorites, toggleFavorite, isFavorite } = useGameFavorites();
  const { recentGames, addRecentGame } = useRecentGames();
  const { getRating, setRating } = useGameRatings();
  const { trackGamePlayed, trackFavoriteAdded, trackGameRated, newlyUnlocked, dismissNewlyUnlocked, unlockedAchievements } = useAchievements();

  const handleGameClick = (gameId: string) => {
    addRecentGame(gameId);
    trackGamePlayed(gameId);
  };

  const handleFavoriteToggle = (gameId: string) => {
    const wasNotFavorite = !isFavorite(gameId);
    toggleFavorite(gameId);
    if (wasNotFavorite) {
      trackFavoriteAdded();
    }
  };

  const handleRating = (gameId: string, rating: number) => {
    const hadNoRating = getRating(gameId) === 0;
    setRating(gameId, rating);
    if (hadNoRating) {
      trackGameRated();
    }
  };

  const recentGamesList = recentGames
    .map(id => games.find(g => g.id === id))
    .filter(Boolean) as typeof games;

  const filteredGames = games.filter(game => {
    const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || 
      (selectedCategory === "favorites" ? isFavorite(game.id) : game.category === selectedCategory);
    return matchesSearch && matchesCategory;
  });

  const sortedGames = [...filteredGames].sort((a, b) => {
    switch (sortBy) {
      case "a-z":
        return a.title.localeCompare(b.title);
      case "z-a":
        return b.title.localeCompare(a.title);
      case "popularity":
        return b.popularity - a.popularity;
      case "newest":
        return b.order - a.order;
      default:
        return a.order - b.order;
    }
  });
  
  const isFiltering = searchQuery || selectedCategory !== "all" || sortBy !== "default";
  const displayedGames = isFiltering ? sortedGames : (showAllGames ? games : games.slice(0, 8));

  useEffect(() => {
    const hasSeenWelcome = localStorage.getItem("gameArenaWelcomeSeen");
    if (!hasSeenWelcome) {
      setShowWelcome(true);
    }
  }, []);

  const handleCloseWelcome = () => {
    setShowWelcome(false);
    localStorage.setItem("gameArenaWelcomeSeen", "true");
  };

  const handleShowMore = () => {
    setIsLoading(true);
    setTimeout(() => {
      setShowAllGames(true);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <>
      <Helmet>
        <title>Game Arena - Play 25+ Free Online Games</title>
        <meta name="description" content="Play 25+ free online games including Snake, Tetris, Chess, Sudoku, and more. Classic arcade games and modern challenges all in one place." />
        <meta name="keywords" content="online games, free games, snake game, tetris, chess, sudoku, arcade games, browser games" />
        <meta property="og:title" content="Game Arena - Play 25+ Free Online Games" />
        <meta property="og:description" content="Your ultimate destination for classic and modern games. Play, compete, and have fun!" />
        <meta property="og:type" content="website" />
        <link rel="canonical" href="https://yourdomain.com/" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-game opacity-30" />
      <div className="absolute top-20 left-20 w-64 h-64 bg-primary rounded-full blur-3xl opacity-20 animate-float" />
      <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: "1s" }} />
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-16">
        <div className="text-center mb-12 animate-slide-up">
          <h1 className="text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-game-pink bg-clip-text text-transparent">
            Game Arena
          </h1>
          <p className="text-xl text-muted-foreground mb-6">Choose your challenge and dominate the leaderboard</p>
          <div className="flex flex-wrap gap-4 justify-center items-center">
            <Link to="/profile">
              <Button size="lg" className="gap-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:scale-105 transition-all duration-300 shadow-game-hover text-white">
                <User className="w-5 h-5" />
                My Profile
              </Button>
            </Link>
            <Link to="/stats">
              <Button size="lg" className="gap-2 bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 shadow-game-hover text-white">
                <BarChart3 className="w-5 h-5" />
                View Statistics
              </Button>
            </Link>
            <Link to="/leaderboard">
              <Button size="lg" className="gap-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:scale-105 transition-all duration-300 shadow-game-hover text-white">
                <Trophy className="w-5 h-5" />
                Leaderboard
              </Button>
            </Link>
            <Link to="/achievements">
              <Button size="lg" className="gap-2 bg-gradient-to-r from-game-pink to-game-purple hover:scale-105 transition-all duration-300 shadow-game-hover text-white">
                <Award className="w-5 h-5" />
                Achievements
                {unlockedAchievements.length > 0 && (
                  <span className="bg-white/20 px-2 py-0.5 rounded-full text-xs">
                    {unlockedAchievements.length}
                  </span>
                )}
              </Button>
            </Link>
          </div>
          
          {/* Search Bar */}
          <div className="max-w-md mx-auto mt-8 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search games..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background/50 border-border/50 focus:border-primary transition-colors"
            />
          </div>

          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-2 mt-6 max-w-4xl mx-auto">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={`transition-all duration-300 hover:scale-105 ${
                  selectedCategory === category.id
                    ? "bg-gradient-to-r from-primary to-secondary text-white shadow-game"
                    : "bg-background/50 border-border/50 hover:border-primary hover:text-white hover:bg-primary"
                }`}
              >
                {category.icon && <category.icon className={`w-4 h-4 mr-1 ${selectedCategory === category.id ? "fill-current" : ""}`} />}
                {category.label}
                {category.id === "favorites" && favorites.length > 0 && (
                  <span className="ml-1.5 bg-background/20 px-1.5 py-0.5 rounded-full text-xs">
                    {favorites.length}
                  </span>
                )}
              </Button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <div className="flex justify-center mt-4">
            <div className="flex items-center gap-2">
              <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
              <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                <SelectTrigger className="w-[180px] bg-background/50 border-border/50">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent className="bg-background border-border">
                  {sortOptions.map((option) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Recent Games Section */}
        {recentGamesList.length > 0 && !isFiltering && (
          <div className="max-w-7xl mx-auto mb-12">
            <div className="flex items-center gap-2 mb-6">
              <History className="w-6 h-6 text-primary" />
              <h2 className="text-2xl font-bold">Recently Played</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {recentGamesList.map((game) => (
                <Link 
                  key={game.id} 
                  to={game.path} 
                  onClick={() => addRecentGame(game.id)}
                  className="group"
                >
                  <Card className="relative overflow-hidden bg-gradient-card border-border hover:border-primary transition-all duration-300 hover:shadow-game-hover hover:-translate-y-1">
                    <div className="p-4 flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${game.color} flex items-center justify-center shadow-game group-hover:scale-110 transition-transform duration-300`}>
                        <game.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold truncate group-hover:text-primary transition-colors">
                          {game.title}
                        </h3>
                        <StarRating rating={getRating(game.id)} readonly size="sm" />
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {displayedGames.map((game, index) => (
            <div key={game.id} className="group h-full relative">
              {/* Favorite Button */}
              <button
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleFavoriteToggle(game.id);
                }}
                className={`absolute top-4 right-4 z-20 p-2 rounded-full transition-all duration-300 ${
                  isFavorite(game.id)
                    ? "bg-game-pink/20 text-game-pink"
                    : "bg-background/50 text-muted-foreground hover:text-game-pink hover:bg-game-pink/10"
                }`}
                aria-label={isFavorite(game.id) ? "Remove from favorites" : "Add to favorites"}
              >
                <Heart className={`w-5 h-5 transition-all duration-300 ${isFavorite(game.id) ? "fill-current scale-110" : ""}`} />
              </button>
              
              <Link to={game.path} className="h-full block" onClick={() => handleGameClick(game.id)}>
                <Card 
                  className="relative overflow-hidden bg-gradient-card border-border hover:border-primary transition-all duration-300 hover:shadow-game-hover hover:-translate-y-2 animate-slide-up h-full flex flex-col"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="p-6 flex flex-col h-full">
                    <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-game group-hover:scale-110 transition-transform duration-300`}>
                      <game.icon className="w-8 h-8 text-white" />
                    </div>
                    
                    <div className="flex-1 mt-4">
                      <h3 className="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">
                        {game.title}
                      </h3>
                      <p className="text-muted-foreground">{game.description}</p>
                      <div className="mt-2" onClick={(e) => e.preventDefault()}>
                        <StarRating 
                          rating={getRating(game.id)} 
                          onRate={(rating) => handleRating(game.id, rating)}
                          size="sm"
                        />
                      </div>
                    </div>

                    <div className="pt-4 flex items-center text-primary font-semibold mt-auto">
                      <span className="group-hover:translate-x-2 transition-transform duration-300">
                        Play Now →
                      </span>
                    </div>
                  </div>

                  {/* Hover Glow Effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/0 to-secondary/0 group-hover:from-primary/10 group-hover:to-secondary/10 transition-all duration-300" />
                </Card>
              </Link>
            </div>
          ))}
        </div>

        {/* No favorites message */}
        {selectedCategory === "favorites" && favorites.length === 0 && (
          <div className="text-center py-12">
            <Heart className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-xl text-muted-foreground">No favorite games yet</p>
            <p className="text-sm text-muted-foreground/70 mt-2">Click the heart icon on any game to add it to your favorites</p>
          </div>
        )}

        {!showAllGames && !isFiltering && games.length > 8 && (
          <div className="text-center mt-12">
            <Button 
              onClick={handleShowMore}
              disabled={isLoading}
              size="lg"
              className="group relative overflow-hidden bg-gradient-to-r from-primary to-secondary hover:scale-105 transition-all duration-300 shadow-game-hover text-white"
            >
              <span className="relative z-10 flex items-center gap-2">
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Loading More Games...
                  </>
                ) : (
                  <>
                    Show More Games
                    <span className="group-hover:translate-x-1 transition-transform">→</span>
                  </>
                )}
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-secondary to-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </Button>
          </div>
        )}

        {/* Welcome Dialog */}
        <Dialog open={showWelcome} onOpenChange={handleCloseWelcome}>
          <DialogContent className="sm:max-w-[500px] border-primary/20 bg-gradient-to-br from-background to-background/95 backdrop-blur animate-scale-in">
            <DialogHeader>
              <DialogTitle className="text-3xl font-bold text-center bg-gradient-to-r from-primary via-secondary to-game-pink bg-clip-text text-transparent animate-fade-in">
                🎮 Welcome to Game Arena! 🎮
              </DialogTitle>
              <DialogDescription className="text-center space-y-4 pt-4">
                <p className="text-lg font-semibold text-foreground animate-slide-up">
                  Congratulations on discovering your new gaming paradise!
                </p>
                <p className="text-muted-foreground animate-slide-up" style={{ animationDelay: "0.1s" }}>
                  Get ready to experience 28 amazing games ranging from classic arcade favorites to modern brain teasers. 
                  Challenge yourself, beat your high scores, and become a gaming legend!
                </p>
                <p className="text-sm text-muted-foreground animate-slide-up" style={{ animationDelay: "0.2s" }}>
                  No downloads, no registration - just pure gaming fun at your fingertips!
                </p>
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-center mt-6 animate-scale-in" style={{ animationDelay: "0.3s" }}>
              <Button 
                onClick={handleCloseWelcome}
                size="lg"
                className="group relative overflow-hidden bg-gradient-to-r from-primary via-secondary to-game-pink hover:scale-105 transition-all duration-300 shadow-game-hover text-white font-bold px-8"
              >
                <span className="relative z-10 flex items-center gap-2 animate-pulse">
                  Start Playing Now! 🚀
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-game-pink via-primary to-secondary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Button>
            </div>
            <hr className="border-border/50 mt-6" />
            <p className="text-center text-xs sm:text-sm text-muted-foreground mt-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
              Powered by{" "}
              <a 
                href="https://hashirkx04.github.io" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:text-secondary transition-colors font-semibold underline underline-offset-2"
              >
                Hashirkx04
              </a>
            </p>
          </DialogContent>
        </Dialog>
      </div>
    </div>
    <Footer />
    <BackToTop />
    {newlyUnlocked && (
      <AchievementToast achievement={newlyUnlocked} onDismiss={dismissNewlyUnlocked} />
    )}
    </>
  );
};

export default GameHub;
