import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Helmet } from "react-helmet";

const WORDS = ["REACT", "GAMES", "PIXEL", "SWIFT", "CLOUD", "BRAVE", "MAGIC", "PRIDE", "QUEST", "STORM"];

const WordGuess = () => {
  const [targetWord, setTargetWord] = useState("");
  const [guesses, setGuesses] = useState<string[]>([]);
  const [currentGuess, setCurrentGuess] = useState("");
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);

  const startGame = () => {
    setTargetWord(WORDS[Math.floor(Math.random() * WORDS.length)]);
    setGuesses([]);
    setCurrentGuess("");
    setGameOver(false);
    setWon(false);
  };

  useEffect(() => {
    startGame();
  }, []);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (gameOver) return;

      if (e.key === 'Enter' && currentGuess.length === 5) {
        submitGuess();
      } else if (e.key === 'Backspace') {
        setCurrentGuess(prev => prev.slice(0, -1));
      } else if (/^[a-zA-Z]$/.test(e.key) && currentGuess.length < 5) {
        setCurrentGuess(prev => prev + e.key.toUpperCase());
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentGuess, gameOver]);

  const submitGuess = () => {
    if (currentGuess.length !== 5) return;

    const newGuesses = [...guesses, currentGuess];
    setGuesses(newGuesses);

    if (currentGuess === targetWord) {
      setWon(true);
      setGameOver(true);
      toast.success(`You won in ${newGuesses.length} guesses! 🎉`);
    } else if (newGuesses.length >= 6) {
      setGameOver(true);
      toast(`Game Over! The word was ${targetWord}`);
    }

    setCurrentGuess("");
  };

  const getLetterColor = (letter: string, position: number, guess: string) => {
    if (guess[position] === targetWord[position]) {
      return "bg-secondary border-secondary";
    } else if (targetWord.includes(letter)) {
      return "bg-game-pink border-game-pink";
    }
    return "bg-muted border-muted";
  };

  return (
    <>
      <Helmet>
        <title>Word Guess - Word Guessing Game | Game Arena</title>
        <meta name="description" content="Play Word Guess online. Test your vocabulary and deduction skills in this classic word guessing game." />
        <meta name="keywords" content="word guess, wordle, word game, vocabulary game, guessing game, 5 letter words" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-game-purple to-game-pink bg-clip-text text-transparent">
              Word Guess
            </h1>
            <p className="mt-4 text-muted-foreground">
              Guesses: <span className="text-primary font-bold">{guesses.length}/6</span>
            </p>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-w-sm mx-auto space-y-4">
          <div className="space-y-2">
            {Array(6).fill(null).map((_, rowIndex) => {
              const guess = rowIndex < guesses.length ? guesses[rowIndex] : 
                           rowIndex === guesses.length ? currentGuess : "";
              
              return (
                <div key={rowIndex} className="grid grid-cols-5 gap-2">
                  {Array(5).fill(null).map((_, colIndex) => {
                    const letter = guess[colIndex] || "";
                    const isSubmitted = rowIndex < guesses.length;
                    
                    return (
                      <Card
                        key={colIndex}
                        className={`aspect-square flex items-center justify-center text-2xl font-bold border-2 transition-all
                          ${isSubmitted 
                            ? getLetterColor(letter, colIndex, guess) + " text-white"
                            : letter 
                              ? "bg-card border-primary" 
                              : "bg-card border-border"
                          }`}
                      >
                        {letter}
                      </Card>
                    );
                  })}
                </div>
              );
            })}
          </div>

          <div className="text-center space-y-4">
            <p className="text-muted-foreground text-sm">Type to guess, Enter to submit</p>
            
            {gameOver && (
              <div className="space-y-2">
                <p className="text-xl font-bold">
                  {won ? "You Won! 🎉" : `Word was: ${targetWord}`}
                </p>
                <Button onClick={startGame} className="bg-primary hover:bg-primary/90">
                  Play Again
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default WordGuess;
