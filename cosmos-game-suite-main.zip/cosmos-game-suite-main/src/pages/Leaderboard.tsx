import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLeaderboard, LeaderboardEntry } from "@/hooks/useLeaderboard";
import { Helmet } from "react-helmet";
import { Trophy, Medal, ArrowLeft, Crown, Trash2 } from "lucide-react";
import { format } from "date-fns";

const gameNames: Record<string, string> = {
  memory: "Memory Match",
  snake: "Snake Game",
  tictactoe: "Tic Tac Toe",
  colormatch: "Color Rush",
  puzzle: "Puzzle Slider",
  simon: "Simon Says",
  whack: "Whack-a-Mole",
  "2048": "2048 Challenge",
  flappy: "Flappy Bird",
  breakout: "Breakout",
  minesweeper: "Minesweeper",
  wordguess: "Word Guess",
  hangman: "Hangman",
  sudoku: "Sudoku",
  tetris: "Tetris",
  pong: "Pong",
  rps: "Rock Paper Scissors",
  trivia: "Trivia Quiz",
  math: "Math Challenge",
  typeracer: "Type Racer",
  platformer: "Platform Jumper",
  blackjack: "Blackjack",
  dice: "Dice Roll",
  connect4: "Connect Four",
  spaceinvaders: "Space Invaders",
  chess: "Chess",
  reactiontime: "Reaction Time",
  targetshooter: "Target Shooter",
};

const Leaderboard = () => {
  const { leaderboard, getAllTopScores, clearLeaderboard } = useLeaderboard();

  const topScoresPerGame = getAllTopScores();

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 0:
        return <Crown className="w-5 h-5 text-yellow-400" />;
      case 1:
        return <Medal className="w-5 h-5 text-gray-400" />;
      case 2:
        return <Medal className="w-5 h-5 text-amber-600" />;
      default:
        return <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank + 1}</span>;
    }
  };

  return (
    <>
      <Helmet>
        <title>Leaderboard - Game Arena</title>
        <meta name="description" content="View top scores and compete for the highest rankings in Game Arena." />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        <div className="absolute top-20 left-20 w-64 h-64 bg-primary rounded-full blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: "1s" }} />

        <div className="relative z-10 container mx-auto px-4 py-16">
          <div className="flex items-center justify-between mb-8">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Games
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="gap-2 text-destructive hover:text-destructive"
              onClick={clearLeaderboard}
            >
              <Trash2 className="w-4 h-4" />
              Clear All
            </Button>
          </div>

          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 mb-4">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-primary to-secondary bg-clip-text text-transparent">
              Leaderboard
            </h1>
            <p className="text-xl text-muted-foreground">Top scores from all games</p>
          </div>

          {topScoresPerGame.length === 0 ? (
            <Card className="max-w-md mx-auto p-8 text-center bg-gradient-card border-border">
              <Trophy className="w-16 h-16 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-xl text-muted-foreground">No scores yet!</p>
              <p className="text-sm text-muted-foreground/70 mt-2">Play some games to see your scores here.</p>
              <Link to="/">
                <Button className="mt-6 bg-gradient-to-r from-primary to-secondary text-white">
                  Start Playing
                </Button>
              </Link>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
              {Object.keys(leaderboard).map((gameId) => {
                const scores = leaderboard[gameId] || [];
                if (scores.length === 0) return null;

                return (
                  <Card key={gameId} className="p-6 bg-gradient-card border-border hover:border-primary transition-all">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                      <Trophy className="w-5 h-5 text-yellow-400" />
                      {gameNames[gameId] || gameId}
                    </h3>
                    <div className="space-y-3">
                      {scores.slice(0, 5).map((entry: LeaderboardEntry, index: number) => (
                        <div
                          key={`${entry.playerName}-${entry.date}`}
                          className={`flex items-center gap-3 p-2 rounded-lg ${
                            index === 0 ? "bg-yellow-400/10 border border-yellow-400/20" : "bg-muted/30"
                          }`}
                        >
                          {getRankIcon(index)}
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold truncate">{entry.playerName}</p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(entry.date), "MMM d, yyyy")}
                            </p>
                          </div>
                          <span className={`font-bold ${index === 0 ? "text-yellow-400" : "text-primary"}`}>
                            {entry.score.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Leaderboard;
