import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

interface Question {
  question: string;
  options: string[];
  correct: number;
}

const questions: Question[] = [
  {
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correct: 2
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correct: 1
  },
  {
    question: "Who painted the Mona Lisa?",
    options: ["Van Gogh", "Picasso", "Da Vinci", "Rembrandt"],
    correct: 2
  },
  {
    question: "What is the largest ocean on Earth?",
    options: ["Atlantic", "Indian", "Arctic", "Pacific"],
    correct: 3
  },
  {
    question: "What year did World War II end?",
    options: ["1943", "1944", "1945", "1946"],
    correct: 2
  }
];

const TriviaQuiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const { toast } = useToast();

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index);
    
    setTimeout(() => {
      if (index === questions[currentQuestion].correct) {
        setScore(score + 1);
        toast({ title: "Correct!", description: "Well done!" });
      } else {
        toast({ title: "Wrong!", description: "Better luck next time", variant: "destructive" });
      }

      if (currentQuestion + 1 < questions.length) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        setShowResult(true);
      }
    }, 1000);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedAnswer(null);
  };

  return (
    <>
      <Helmet>
        <title>Trivia Quiz - Test Your Knowledge | Game Arena</title>
        <meta name="description" content="Test your knowledge with our Trivia Quiz. Answer questions on various topics and challenge yourself!" />
        <meta name="keywords" content="trivia quiz, trivia game, quiz game, knowledge test, general knowledge quiz" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Trivia Quiz
          </h1>
          <div className="text-2xl font-bold">Score: {score}</div>
        </div>

        {!showResult ? (
          <Card className="p-8">
            <div className="mb-6">
              <div className="text-sm text-muted-foreground mb-2">
                Question {currentQuestion + 1} of {questions.length}
              </div>
              <h2 className="text-2xl font-bold mb-6">
                {questions[currentQuestion].question}
              </h2>
            </div>

            <div className="grid gap-4">
              {questions[currentQuestion].options.map((option, index) => (
                <Button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  variant={
                    selectedAnswer === null 
                      ? "outline" 
                      : index === questions[currentQuestion].correct 
                        ? "default" 
                        : selectedAnswer === index 
                          ? "destructive" 
                          : "outline"
                  }
                  disabled={selectedAnswer !== null}
                  className="h-auto p-4 text-left justify-start"
                >
                  {option}
                </Button>
              ))}
            </div>
          </Card>
        ) : (
          <Card className="p-8 text-center">
            <h2 className="text-4xl font-bold mb-4">Quiz Complete!</h2>
            <div className="text-6xl font-bold text-primary mb-6">
              {score} / {questions.length}
            </div>
            <div className="text-2xl mb-8">
              {score === questions.length ? "Perfect Score! 🎉" : score >= 3 ? "Great Job! 👏" : "Keep Practicing! 💪"}
            </div>
            <Button onClick={resetQuiz} size="lg">Play Again</Button>
          </Card>
        )}
      </div>
    </div>
    </>
  );
};

export default TriviaQuiz;
