import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAchievements, achievements } from "@/hooks/useAchievements";
import { Helmet } from "react-helmet";
import { ArrowLeft, Trophy, Lock } from "lucide-react";
import { format } from "date-fns";

const Achievements = () => {
  const { isUnlocked, getUnlockDate, progress, unlockedAchievements } = useAchievements();

  const categories = [
    { id: "games", label: "Games Played", icon: "🎮" },
    { id: "scores", label: "High Scores", icon: "🏆" },
    { id: "social", label: "Social", icon: "❤️" },
    { id: "special", label: "Special", icon: "⭐" },
  ];

  const unlockedCount = unlockedAchievements.length;
  const totalCount = achievements.length;
  const progressPercent = (unlockedCount / totalCount) * 100;

  return (
    <>
      <Helmet>
        <title>Achievements - Game Arena</title>
        <meta name="description" content="View your achievements and badges earned in Game Arena." />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        <div className="absolute top-20 left-20 w-64 h-64 bg-primary rounded-full blur-3xl opacity-20 animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: "1s" }} />

        <div className="relative z-10 container mx-auto px-4 py-16">
          <div className="flex items-center justify-between mb-8">
            <Link to="/">
              <Button variant="outline" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Games
              </Button>
            </Link>
          </div>

          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary mb-4">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-secondary to-game-pink bg-clip-text text-transparent">
              Achievements
            </h1>
            <p className="text-xl text-muted-foreground mb-6">
              {unlockedCount} of {totalCount} achievements unlocked
            </p>
            <div className="max-w-md mx-auto">
              <Progress value={progressPercent} className="h-3" />
            </div>
          </div>

          {/* Stats Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12">
            <Card className="p-4 bg-gradient-card border-border text-center">
              <p className="text-3xl font-bold text-primary">{progress.gamesPlayed}</p>
              <p className="text-sm text-muted-foreground">Games Played</p>
            </Card>
            <Card className="p-4 bg-gradient-card border-border text-center">
              <p className="text-3xl font-bold text-secondary">{progress.uniqueGamesPlayed.length}</p>
              <p className="text-sm text-muted-foreground">Unique Games</p>
            </Card>
            <Card className="p-4 bg-gradient-card border-border text-center">
              <p className="text-3xl font-bold text-game-pink">{progress.scoresSubmitted}</p>
              <p className="text-sm text-muted-foreground">Scores Submitted</p>
            </Card>
            <Card className="p-4 bg-gradient-card border-border text-center">
              <p className="text-3xl font-bold text-yellow-400">{progress.gamesRated}</p>
              <p className="text-sm text-muted-foreground">Games Rated</p>
            </Card>
          </div>

          {/* Achievement Categories */}
          {categories.map((category) => {
            const categoryAchievements = achievements.filter((a) => a.category === category.id);
            
            return (
              <div key={category.id} className="max-w-5xl mx-auto mb-10">
                <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                  <span>{category.icon}</span>
                  {category.label}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryAchievements.map((achievement) => {
                    const unlocked = isUnlocked(achievement.id);
                    const unlockDate = getUnlockDate(achievement.id);

                    return (
                      <Card
                        key={achievement.id}
                        className={`p-4 transition-all ${
                          unlocked
                            ? "bg-gradient-to-br from-yellow-500/10 to-yellow-600/5 border-yellow-500/30"
                            : "bg-gradient-card border-border opacity-60"
                        }`}
                      >
                        <div className="flex items-start gap-4">
                          <div
                            className={`w-14 h-14 rounded-xl flex items-center justify-center text-2xl ${
                              unlocked
                                ? "bg-gradient-to-br from-yellow-400 to-yellow-600"
                                : "bg-muted"
                            }`}
                          >
                            {unlocked ? achievement.icon : <Lock className="w-6 h-6 text-muted-foreground" />}
                          </div>
                          <div className="flex-1">
                            <h3 className={`font-bold ${unlocked ? "text-foreground" : "text-muted-foreground"}`}>
                              {achievement.title}
                            </h3>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                            {unlocked && unlockDate && (
                              <p className="text-xs text-yellow-500 mt-1">
                                Unlocked {format(unlockDate, "MMM d, yyyy")}
                              </p>
                            )}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Achievements;
