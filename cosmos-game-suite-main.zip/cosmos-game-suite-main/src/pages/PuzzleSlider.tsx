import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";

type Tile = number | null;

const PuzzleSlider = () => {
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [moves, setMoves] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const audio = useGameAudio();

  const initializeGame = () => {
    const numbers: Tile[] = [1, 2, 3, 4, 5, 6, 7, 8, null];
    const shuffled = [...numbers].sort(() => Math.random() - 0.5);
    setTiles(shuffled);
    setMoves(0);
    setIsComplete(false);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  const checkWin = (currentTiles: Tile[]) => {
    const winState = [1, 2, 3, 4, 5, 6, 7, 8, null];
    return currentTiles.every((tile, index) => tile === winState[index]);
  };

  const handleTileClick = (index: number) => {
    if (isComplete) return;

    const emptyIndex = tiles.indexOf(null);
    const validMoves = [
      emptyIndex - 1,
      emptyIndex + 1,
      emptyIndex - 3,
      emptyIndex + 3,
    ];

    if (
      validMoves.includes(index) &&
      !(emptyIndex % 3 === 0 && index === emptyIndex - 1) &&
      !(emptyIndex % 3 === 2 && index === emptyIndex + 1)
    ) {
      audio.playMoveSound();
      const newTiles = [...tiles];
      [newTiles[emptyIndex], newTiles[index]] = [newTiles[index], newTiles[emptyIndex]];
      setTiles(newTiles);
      setMoves(moves + 1);

      if (checkWin(newTiles)) {
        setIsComplete(true);
        setTimeout(() => {
          audio.playWinSound();
          toast.success(`Puzzle solved in ${moves + 1} moves! 🎉`);
        }, 300);
      }
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-game-purple to-primary bg-clip-text text-transparent">
              Puzzle Slider
            </h1>
            <p className="mt-4 text-muted-foreground">
              Moves: <span className="text-primary font-bold">{moves}</span>
            </p>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={initializeGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="mb-6">
          <AudioControls
            volume={audio.volume}
            isMuted={audio.isMuted}
            onVolumeChange={audio.setVolume}
            onToggleMute={audio.toggleMute}
          />
        </div>

        <div className="grid grid-cols-3 gap-3 max-w-md mx-auto">
          {tiles.map((tile, index) => (
            <Card
              key={index}
              onClick={() => handleTileClick(index)}
              className={`aspect-square flex items-center justify-center text-5xl font-bold cursor-pointer transition-all duration-200 border-border
                ${tile === null ? 'bg-muted/20' : 'bg-gradient-to-br from-game-purple to-primary hover:border-primary hover:shadow-game'}`}
            >
              {tile !== null && <span className="text-white">{tile}</span>}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PuzzleSlider;
