import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Play, RotateCcw } from "lucide-react";
import { Helmet } from "react-helmet";
import Footer from "@/components/Footer";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";

const ReactionTime = () => {
  const [gameState, setGameState] = useState<"idle" | "waiting" | "ready" | "clicked" | "tooEarly">("idle");
  const [reactionTime, setReactionTime] = useState<number | null>(null);
  const [bestTime, setBestTime] = useState<number | null>(null);
  const [attempts, setAttempts] = useState<number[]>([]);
  const startTimeRef = useRef<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout>();
  const audio = useGameAudio();

  useEffect(() => {
    const saved = localStorage.getItem("reactionTimeBest");
    if (saved) setBestTime(parseInt(saved));
  }, []);

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const startGame = () => {
    setGameState("waiting");
    setReactionTime(null);
    const delay = Math.random() * 3000 + 2000; // 2-5 seconds
    
    timeoutRef.current = setTimeout(() => {
      setGameState("ready");
      startTimeRef.current = Date.now();
    }, delay);
  };

  const handleClick = () => {
    if (gameState === "waiting") {
      audio.playErrorSound();
      setGameState("tooEarly");
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      return;
    }

    if (gameState === "ready") {
      audio.playSuccessSound();
      const time = Date.now() - startTimeRef.current;
      setReactionTime(time);
      setAttempts([...attempts, time]);
      setGameState("clicked");

      if (!bestTime || time < bestTime) {
        setBestTime(time);
        localStorage.setItem("reactionTimeBest", time.toString());
      }
    }
  };

  const reset = () => {
    setGameState("idle");
    setReactionTime(null);
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
  };

  const getAverageTime = () => {
    if (attempts.length === 0) return null;
    return Math.round(attempts.reduce((a, b) => a + b, 0) / attempts.length);
  };

  const getBackgroundColor = () => {
    switch (gameState) {
      case "waiting":
        return "bg-red-500/20";
      case "ready":
        return "bg-green-500/20";
      case "tooEarly":
        return "bg-yellow-500/20";
      default:
        return "bg-background";
    }
  };

  return (
    <>
      <Helmet>
        <title>Reaction Time Test - Game Arena</title>
        <meta name="description" content="Test your reflexes with the reaction time game. See how fast you can click when the screen turns green!" />
        <meta name="keywords" content="reaction time, reflex test, speed test, gaming reflexes, click speed" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        
        <div className="relative z-10 container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Link to="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Reaction Time Test
            </h1>
          </div>

          <div className="mb-6">
            <AudioControls
              volume={audio.volume}
              isMuted={audio.isMuted}
              onVolumeChange={audio.setVolume}
              onToggleMute={audio.toggleMute}
            />
          </div>

          <div className="max-w-2xl mx-auto space-y-6">
            <Card className="p-8 bg-gradient-card border-border">
              <div className="space-y-4 text-center mb-6">
                <p className="text-muted-foreground">
                  {gameState === "idle" && "Click 'Start' and wait for the green screen, then click as fast as you can!"}
                  {gameState === "waiting" && "Wait for green..."}
                  {gameState === "ready" && "CLICK NOW!"}
                  {gameState === "clicked" && `Your reaction time: ${reactionTime}ms`}
                  {gameState === "tooEarly" && "Too early! Wait for green."}
                </p>
              </div>

              <div
                onClick={handleClick}
                className={`w-full h-64 rounded-lg border-2 border-border flex items-center justify-center cursor-pointer transition-all duration-300 ${getBackgroundColor()}`}
              >
                {gameState === "idle" && (
                  <div className="text-center">
                    <Play className="w-16 h-16 mx-auto mb-4 text-primary" />
                    <p className="text-xl">Click to Start</p>
                  </div>
                )}
                {gameState === "waiting" && (
                  <p className="text-2xl font-bold text-red-500">Wait...</p>
                )}
                {gameState === "ready" && (
                  <p className="text-3xl font-bold text-green-500 animate-pulse">CLICK!</p>
                )}
                {gameState === "clicked" && (
                  <div className="text-center">
                    <p className="text-5xl font-bold text-primary mb-2">{reactionTime}ms</p>
                    <p className="text-muted-foreground">Click to try again</p>
                  </div>
                )}
                {gameState === "tooEarly" && (
                  <div className="text-center">
                    <p className="text-2xl font-bold text-yellow-500 mb-2">Too Early!</p>
                    <p className="text-muted-foreground">Click to try again</p>
                  </div>
                )}
              </div>

              <div className="mt-6 flex gap-4">
                {(gameState === "clicked" || gameState === "tooEarly") && (
                  <Button onClick={startGame} className="flex-1">
                    <Play className="mr-2 h-4 w-4" />
                    Try Again
                  </Button>
                )}
                {gameState === "idle" && (
                  <Button onClick={startGame} className="flex-1">
                    <Play className="mr-2 h-4 w-4" />
                    Start Test
                  </Button>
                )}
                {gameState !== "idle" && (
                  <Button onClick={reset} variant="outline">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                )}
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {bestTime && (
                <Card className="p-4 text-center bg-gradient-card border-border">
                  <p className="text-sm text-muted-foreground mb-1">Best Time</p>
                  <p className="text-2xl font-bold text-primary">{bestTime}ms</p>
                </Card>
              )}
              {attempts.length > 0 && (
                <Card className="p-4 text-center bg-gradient-card border-border">
                  <p className="text-sm text-muted-foreground mb-1">Average</p>
                  <p className="text-2xl font-bold text-secondary">{getAverageTime()}ms</p>
                </Card>
              )}
              {attempts.length > 0 && (
                <Card className="p-4 text-center bg-gradient-card border-border">
                  <p className="text-sm text-muted-foreground mb-1">Attempts</p>
                  <p className="text-2xl font-bold text-game-pink">{attempts.length}</p>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ReactionTime;
