import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw, Flag } from "lucide-react";
import { toast } from "sonner";

type Cell = {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  neighborMines: number;
};

const Minesweeper = () => {
  const ROWS = 9;
  const COLS = 9;
  const MINES = 10;

  const [grid, setGrid] = useState<Cell[][]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [flagsLeft, setFlagsLeft] = useState(MINES);

  const createGrid = () => {
    const newGrid: Cell[][] = Array(ROWS).fill(null).map(() =>
      Array(COLS).fill(null).map(() => ({
        isMine: false,
        isRevealed: false,
        isFlagged: false,
        neighborMines: 0,
      }))
    );

    let minesPlaced = 0;
    while (minesPlaced < MINES) {
      const row = Math.floor(Math.random() * ROWS);
      const col = Math.floor(Math.random() * COLS);
      if (!newGrid[row][col].isMine) {
        newGrid[row][col].isMine = true;
        minesPlaced++;
      }
    }

    for (let i = 0; i < ROWS; i++) {
      for (let j = 0; j < COLS; j++) {
        if (!newGrid[i][j].isMine) {
          let count = 0;
          for (let di = -1; di <= 1; di++) {
            for (let dj = -1; dj <= 1; dj++) {
              const ni = i + di;
              const nj = j + dj;
              if (ni >= 0 && ni < ROWS && nj >= 0 && nj < COLS && newGrid[ni][nj].isMine) {
                count++;
              }
            }
          }
          newGrid[i][j].neighborMines = count;
        }
      }
    }

    return newGrid;
  };

  const startGame = () => {
    setGrid(createGrid());
    setGameOver(false);
    setWon(false);
    setFlagsLeft(MINES);
  };

  useEffect(() => {
    startGame();
  }, []);

  const revealCell = (row: number, col: number) => {
    if (gameOver || won || grid[row][col].isRevealed || grid[row][col].isFlagged) return;

    const newGrid = grid.map(r => r.map(c => ({ ...c })));

    if (newGrid[row][col].isMine) {
      newGrid[row][col].isRevealed = true;
      setGrid(newGrid);
      setGameOver(true);
      toast.error("Game Over! You hit a mine!");
      return;
    }

    const reveal = (r: number, c: number) => {
      if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return;
      if (newGrid[r][c].isRevealed || newGrid[r][c].isFlagged) return;

      newGrid[r][c].isRevealed = true;

      if (newGrid[r][c].neighborMines === 0) {
        for (let di = -1; di <= 1; di++) {
          for (let dj = -1; dj <= 1; dj++) {
            reveal(r + di, c + dj);
          }
        }
      }
    };

    reveal(row, col);
    setGrid(newGrid);

    const revealedCount = newGrid.flat().filter(c => c.isRevealed).length;
    if (revealedCount === ROWS * COLS - MINES) {
      setWon(true);
      toast.success("You won! 🎉");
    }
  };

  const toggleFlag = (row: number, col: number, e: React.MouseEvent) => {
    e.preventDefault();
    if (gameOver || won || grid[row][col].isRevealed) return;

    const newGrid = grid.map(r => r.map(c => ({ ...c })));
    newGrid[row][col].isFlagged = !newGrid[row][col].isFlagged;
    setFlagsLeft(prev => prev + (newGrid[row][col].isFlagged ? -1 : 1));
    setGrid(newGrid);
  };

  const getCellColor = (cell: Cell) => {
    if (!cell.isRevealed) return "bg-muted hover:bg-muted/70";
    if (cell.isMine) return "bg-destructive";
    return "bg-card";
  };

  const getNumberColor = (num: number) => {
    const colors = ["", "text-primary", "text-secondary", "text-destructive", "text-game-purple", "text-game-pink"];
    return colors[num] || "text-foreground";
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Minesweeper
            </h1>
            <p className="mt-4 text-muted-foreground flex items-center justify-center gap-2">
              <Flag className="w-4 h-4" />
              Flags Left: <span className="text-primary font-bold">{flagsLeft}</span>
            </p>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-w-md mx-auto space-y-4">
          <div className="grid grid-cols-9 gap-1 bg-border p-2 rounded-lg">
            {grid.map((row, i) =>
              row.map((cell, j) => (
                <Card
                  key={`${i}-${j}`}
                  onClick={() => revealCell(i, j)}
                  onContextMenu={(e) => toggleFlag(i, j, e)}
                  className={`aspect-square flex items-center justify-center text-sm font-bold cursor-pointer transition-all border-border
                    ${getCellColor(cell)}`}
                >
                  {cell.isFlagged ? (
                    <Flag className="w-3 h-3 text-destructive" />
                  ) : cell.isRevealed ? (
                    cell.isMine ? (
                      "💣"
                    ) : cell.neighborMines > 0 ? (
                      <span className={getNumberColor(cell.neighborMines)}>{cell.neighborMines}</span>
                    ) : null
                  ) : null}
                </Card>
              ))
            )}
          </div>
          <p className="text-center text-muted-foreground text-sm">Left click to reveal, right click to flag</p>
        </div>
      </div>
    </div>
  );
};

export default Minesweeper;
