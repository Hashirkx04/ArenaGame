import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

type CardType = { value: string; suit: string; numValue: number };

const Blackjack = () => {
  const [playerHand, setPlayerHand] = useState<CardType[]>([]);
  const [dealerHand, setDealerHand] = useState<CardType[]>([]);
  const [playerScore, setPlayerScore] = useState(0);
  const [dealerScore, setDealerScore] = useState(0);
  const [balance, setBalance] = useState(1000);
  const [bet, setBet] = useState(100);
  const [gameState, setGameState] = useState<"betting" | "playing" | "ended">("betting");
  const { toast } = useToast();

  const suits = ["♠", "♥", "♦", "♣"];
  const values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

  const getCardValue = (value: string, currentTotal: number): number => {
    if (value === "A") return currentTotal + 11 > 21 ? 1 : 11;
    if (["J", "Q", "K"].includes(value)) return 10;
    return parseInt(value);
  };

  const createCard = (): CardType => {
    const value = values[Math.floor(Math.random() * values.length)];
    const suit = suits[Math.floor(Math.random() * suits.length)];
    return { value, suit, numValue: 0 };
  };

  const calculateScore = (hand: CardType[]): number => {
    let score = 0;
    let aces = 0;
    
    hand.forEach(card => {
      if (card.value === "A") {
        aces++;
        score += 11;
      } else if (["J", "Q", "K"].includes(card.value)) {
        score += 10;
      } else {
        score += parseInt(card.value);
      }
    });

    while (score > 21 && aces > 0) {
      score -= 10;
      aces--;
    }

    return score;
  };

  const startGame = () => {
    if (bet > balance) {
      toast({ title: "Insufficient Balance", variant: "destructive" });
      return;
    }

    const newPlayerHand = [createCard(), createCard()];
    const newDealerHand = [createCard(), createCard()];
    
    setPlayerHand(newPlayerHand);
    setDealerHand(newDealerHand);
    setPlayerScore(calculateScore(newPlayerHand));
    setDealerScore(calculateScore(newDealerHand));
    setGameState("playing");
    setBalance(balance - bet);
  };

  const hit = () => {
    const newHand = [...playerHand, createCard()];
    setPlayerHand(newHand);
    const newScore = calculateScore(newHand);
    setPlayerScore(newScore);
    
    if (newScore > 21) {
      endGame("bust");
    }
  };

  const stand = () => {
    let newDealerHand = [...dealerHand];
    let score = calculateScore(newDealerHand);
    
    while (score < 17) {
      newDealerHand.push(createCard());
      score = calculateScore(newDealerHand);
    }
    
    setDealerHand(newDealerHand);
    setDealerScore(score);
    
    if (score > 21) {
      endGame("win");
    } else if (score > playerScore) {
      endGame("lose");
    } else if (score < playerScore) {
      endGame("win");
    } else {
      endGame("push");
    }
  };

  const endGame = (result: string) => {
    setGameState("ended");
    
    if (result === "win") {
      setBalance(balance + bet * 2);
      toast({ title: "You Win!", description: `+$${bet}` });
    } else if (result === "push") {
      setBalance(balance + bet);
      toast({ title: "Push", description: "Bet returned" });
    } else {
      toast({ title: "You Lose", variant: "destructive" });
    }
  };

  return (
    <>
      <Helmet>
        <title>Blackjack - Casino Card Game | Game Arena</title>
        <meta name="description" content="Play Blackjack online. Beat the dealer and get as close to 21 as possible in this classic casino card game." />
        <meta name="keywords" content="blackjack, 21 card game, blackjack online, casino game, card game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Blackjack
          </h1>
          <div className="text-2xl font-bold">💰 ${balance}</div>
        </div>

        {gameState === "betting" && (
          <Card className="p-8 text-center">
            <h2 className="text-3xl font-bold mb-6">Place Your Bet</h2>
            <div className="flex gap-4 justify-center mb-6">
              {[50, 100, 250, 500].map(amount => (
                <Button
                  key={amount}
                  onClick={() => setBet(amount)}
                  variant={bet === amount ? "default" : "outline"}
                >
                  ${amount}
                </Button>
              ))}
            </div>
            <Button onClick={startGame} size="lg">Deal Cards</Button>
          </Card>
        )}

        {gameState !== "betting" && (
          <>
            <Card className="p-6 mb-4">
              <h3 className="text-xl font-bold mb-4">Dealer: {gameState === "ended" ? dealerScore : "?"}</h3>
              <div className="flex gap-2">
                {dealerHand.map((card, i) => (
                  <div key={i} className="w-20 h-28 bg-card border-2 rounded flex flex-col items-center justify-center">
                    {gameState === "ended" || i === 0 ? (
                      <>
                        <span className="text-3xl">{card.value}</span>
                        <span className="text-2xl">{card.suit}</span>
                      </>
                    ) : (
                      <span className="text-4xl">🂠</span>
                    )}
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 mb-6">
              <h3 className="text-xl font-bold mb-4">You: {playerScore}</h3>
              <div className="flex gap-2">
                {playerHand.map((card, i) => (
                  <div key={i} className="w-20 h-28 bg-card border-2 rounded flex flex-col items-center justify-center">
                    <span className="text-3xl">{card.value}</span>
                    <span className="text-2xl">{card.suit}</span>
                  </div>
                ))}
              </div>
            </Card>

            {gameState === "playing" && (
              <div className="flex gap-4 justify-center">
                <Button onClick={hit} size="lg">Hit</Button>
                <Button onClick={stand} size="lg" variant="outline">Stand</Button>
              </div>
            )}

            {gameState === "ended" && (
              <div className="text-center">
                <Button onClick={() => setGameState("betting")} size="lg">New Round</Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
    </>
  );
};

export default Blackjack;
