import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";

type Grid = number[][];

const Game2048 = () => {
  const [grid, setGrid] = useState<Grid>([]);
  const [score, setScore] = useState(0);
  const [bestScore, setBestScore] = useState(0);

  const initializeGrid = (): Grid => {
    const newGrid = Array(4).fill(null).map(() => Array(4).fill(0));
    addNewTile(newGrid);
    addNewTile(newGrid);
    return newGrid;
  };

  const addNewTile = (currentGrid: Grid) => {
    const emptyCells: [number, number][] = [];
    currentGrid.forEach((row, i) => {
      row.forEach((cell, j) => {
        if (cell === 0) emptyCells.push([i, j]);
      });
    });
    
    if (emptyCells.length > 0) {
      const [i, j] = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      currentGrid[i][j] = Math.random() < 0.9 ? 2 : 4;
    }
  };

  const startGame = () => {
    setGrid(initializeGrid());
    setScore(0);
  };

  useEffect(() => {
    startGame();
  }, []);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
        move(e.key);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [grid]);

  const move = (direction: string) => {
    let newGrid = grid.map(row => [...row]);
    let moved = false;
    let newScore = score;

    const moveLeft = (row: number[]): number[] => {
      const filtered = row.filter(cell => cell !== 0);
      const merged: number[] = [];
      
      for (let i = 0; i < filtered.length; i++) {
        if (filtered[i] === filtered[i + 1]) {
          merged.push(filtered[i] * 2);
          newScore += filtered[i] * 2;
          i++;
          moved = true;
        } else {
          merged.push(filtered[i]);
        }
      }
      
      while (merged.length < 4) merged.push(0);
      return merged;
    };

    const transpose = (g: Grid): Grid => 
      g[0].map((_, i) => g.map(row => row[i]));

    const reverse = (g: Grid): Grid => 
      g.map(row => [...row].reverse());

    if (direction === 'ArrowLeft') {
      newGrid = newGrid.map(row => moveLeft(row));
    } else if (direction === 'ArrowRight') {
      newGrid = reverse(newGrid).map(row => moveLeft(row));
      newGrid = reverse(newGrid);
    } else if (direction === 'ArrowUp') {
      newGrid = transpose(newGrid).map(row => moveLeft(row));
      newGrid = transpose(newGrid);
    } else if (direction === 'ArrowDown') {
      newGrid = transpose(reverse(newGrid)).map(row => moveLeft(row));
      newGrid = reverse(transpose(newGrid));
    }

    if (JSON.stringify(newGrid) !== JSON.stringify(grid)) {
      addNewTile(newGrid);
      setGrid(newGrid);
      setScore(newScore);
      
      if (newScore > bestScore) {
        setBestScore(newScore);
      }

      if (newGrid.some(row => row.includes(2048))) {
        toast.success("You reached 2048! 🎉");
      }
    }
  };

  const getTileColor = (value: number) => {
    const colors: Record<number, string> = {
      0: "bg-muted/30",
      2: "bg-card",
      4: "bg-muted",
      8: "bg-primary/50",
      16: "bg-primary/70",
      32: "bg-primary",
      64: "bg-secondary/70",
      128: "bg-secondary",
      256: "bg-game-pink/70",
      512: "bg-game-pink",
      1024: "bg-game-glow",
      2048: "bg-gradient-to-br from-primary via-secondary to-game-pink",
    };
    return colors[value] || "bg-game-glow";
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-secondary to-game-glow bg-clip-text text-transparent">
              2048 Challenge
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>Best: <span className="text-secondary font-bold">{bestScore}</span></span>
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-w-md mx-auto space-y-4">
          <p className="text-center text-muted-foreground">Use arrow keys to play</p>
          
          <div className="grid grid-cols-4 gap-3 bg-muted/20 p-3 rounded-lg">
            {grid.map((row, i) => 
              row.map((cell, j) => (
                <Card
                  key={`${i}-${j}`}
                  className={`aspect-square flex items-center justify-center text-2xl font-bold border-border transition-all duration-200 
                    ${getTileColor(cell)}
                    ${cell > 0 ? 'text-white' : 'text-transparent'}`}
                >
                  {cell > 0 ? cell : ''}
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Game2048;
