import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const Breakout = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);

  const gameState = useRef({
    ballX: 200,
    ballY: 300,
    ballDX: 3,
    ballDY: -3,
    paddleX: 160,
    bricks: [] as boolean[][],
  });

  const CANVAS_WIDTH = 400;
  const CANVAS_HEIGHT = 500;
  const BALL_RADIUS = 8;
  const PADDLE_WIDTH = 80;
  const PADDLE_HEIGHT = 10;
  const BRICK_ROWS = 5;
  const BRICK_COLS = 8;
  const BRICK_WIDTH = 45;
  const BRICK_HEIGHT = 20;
  const BRICK_PADDING = 5;

  const initBricks = () => {
    const bricks: boolean[][] = [];
    for (let i = 0; i < BRICK_ROWS; i++) {
      bricks[i] = [];
      for (let j = 0; j < BRICK_COLS; j++) {
        bricks[i][j] = true;
      }
    }
    return bricks;
  };

  const startGame = () => {
    gameState.current = {
      ballX: 200,
      ballY: 300,
      ballDX: 3,
      ballDY: -3,
      paddleX: 160,
      bricks: initBricks(),
    };
    setScore(0);
    setLives(3);
    setIsPlaying(true);
    setGameOver(false);
    setWon(false);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      gameState.current.paddleX = e.clientX - rect.left - PADDLE_WIDTH / 2;
      if (gameState.current.paddleX < 0) gameState.current.paddleX = 0;
      if (gameState.current.paddleX > CANVAS_WIDTH - PADDLE_WIDTH) {
        gameState.current.paddleX = CANVAS_WIDTH - PADDLE_WIDTH;
      }
    };

    canvas.addEventListener('mousemove', handleMouseMove);

    return () => canvas.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    if (!isPlaying || gameOver || won) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gameLoop = setInterval(() => {
      const state = gameState.current;

      ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Draw ball
      ctx.beginPath();
      ctx.arc(state.ballX, state.ballY, BALL_RADIUS, 0, Math.PI * 2);
      ctx.fillStyle = '#06b6d4';
      ctx.fill();
      ctx.closePath();

      // Draw paddle
      ctx.fillStyle = '#a855f7';
      ctx.fillRect(state.paddleX, CANVAS_HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT);

      // Draw bricks
      for (let i = 0; i < BRICK_ROWS; i++) {
        for (let j = 0; j < BRICK_COLS; j++) {
          if (state.bricks[i][j]) {
            const brickX = j * (BRICK_WIDTH + BRICK_PADDING) + BRICK_PADDING;
            const brickY = i * (BRICK_HEIGHT + BRICK_PADDING) + 30;
            ctx.fillStyle = `hsl(${i * 40 + j * 10}, 70%, 60%)`;
            ctx.fillRect(brickX, brickY, BRICK_WIDTH, BRICK_HEIGHT);
          }
        }
      }

      // Ball movement
      state.ballX += state.ballDX;
      state.ballY += state.ballDY;

      // Wall collision
      if (state.ballX + BALL_RADIUS > CANVAS_WIDTH || state.ballX - BALL_RADIUS < 0) {
        state.ballDX = -state.ballDX;
      }
      if (state.ballY - BALL_RADIUS < 0) {
        state.ballDY = -state.ballDY;
      }

      // Paddle collision
      if (
        state.ballY + BALL_RADIUS > CANVAS_HEIGHT - 30 &&
        state.ballX > state.paddleX &&
        state.ballX < state.paddleX + PADDLE_WIDTH
      ) {
        state.ballDY = -state.ballDY;
      }

      // Bottom wall
      if (state.ballY + BALL_RADIUS > CANVAS_HEIGHT) {
        const newLives = lives - 1;
        setLives(newLives);
        if (newLives <= 0) {
          setGameOver(true);
          setIsPlaying(false);
          toast(`Game Over! Score: ${score}`);
        } else {
          state.ballX = 200;
          state.ballY = 300;
          state.ballDX = 3;
          state.ballDY = -3;
        }
      }

      // Brick collision
      for (let i = 0; i < BRICK_ROWS; i++) {
        for (let j = 0; j < BRICK_COLS; j++) {
          if (state.bricks[i][j]) {
            const brickX = j * (BRICK_WIDTH + BRICK_PADDING) + BRICK_PADDING;
            const brickY = i * (BRICK_HEIGHT + BRICK_PADDING) + 30;
            
            if (
              state.ballX > brickX &&
              state.ballX < brickX + BRICK_WIDTH &&
              state.ballY > brickY &&
              state.ballY < brickY + BRICK_HEIGHT
            ) {
              state.ballDY = -state.ballDY;
              state.bricks[i][j] = false;
              setScore(s => s + 10);

              // Check win
              if (state.bricks.every(row => row.every(brick => !brick))) {
                setWon(true);
                setIsPlaying(false);
                toast.success(`You won! Score: ${score + 10} 🎉`);
              }
            }
          }
        }
      }
    }, 16);

    return () => clearInterval(gameLoop);
  }, [isPlaying, gameOver, won, lives, score]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-game-pink to-primary bg-clip-text text-transparent">
              Breakout
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>Lives: <span className="text-destructive font-bold">{lives}</span></span>
            </div>
          </div>

          <div className="w-10" />
        </div>

        <div className="max-w-md mx-auto space-y-4">
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={CANVAS_WIDTH}
              height={CANVAS_HEIGHT}
              className="border-2 border-border rounded-lg bg-card mx-auto"
            />
            
            {!isPlaying && !gameOver && !won && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-lg">
                <Button onClick={startGame} size="lg" className="bg-primary hover:bg-primary/90">
                  Start Game
                </Button>
              </div>
            )}

            {(gameOver || won) && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-lg">
                <div className="text-center">
                  <p className="text-2xl font-bold text-foreground mb-4">
                    {won ? 'You Won!' : 'Game Over!'}
                  </p>
                  <Button onClick={startGame} className="bg-primary hover:bg-primary/90">
                    Play Again
                  </Button>
                </div>
              </div>
            )}
          </div>
          <p className="text-center text-muted-foreground text-sm">Move mouse to control paddle</p>
        </div>
      </div>
    </div>
  );
};

export default Breakout;
