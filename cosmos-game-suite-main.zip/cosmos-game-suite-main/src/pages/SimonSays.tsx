import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";

const colors = ["red", "blue", "green", "yellow"];
const colorClasses = {
  red: "bg-destructive hover:bg-destructive/80",
  blue: "bg-primary hover:bg-primary/80",
  green: "bg-game-glow hover:bg-game-glow/80",
  yellow: "bg-game-pink hover:bg-game-pink/80",
};

const SimonSays = () => {
  const [sequence, setSequence] = useState<string[]>([]);
  const [userSequence, setUserSequence] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [activeColor, setActiveColor] = useState<string | null>(null);

  const startGame = () => {
    const newColor = colors[Math.floor(Math.random() * colors.length)];
    setSequence([newColor]);
    setUserSequence([]);
    setScore(0);
    setCurrentIndex(0);
    setIsPlaying(true);
  };

  const playSequence = async () => {
    setIsPlaying(true);
    for (let i = 0; i < sequence.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 500));
      setActiveColor(sequence[i]);
      await new Promise(resolve => setTimeout(resolve, 500));
      setActiveColor(null);
    }
    setIsPlaying(false);
  };

  useEffect(() => {
    if (sequence.length > 0 && userSequence.length === 0) {
      playSequence();
    }
  }, [sequence]);

  const handleColorClick = (color: string) => {
    if (isPlaying) return;

    const newUserSequence = [...userSequence, color];
    setUserSequence(newUserSequence);

    if (sequence[currentIndex] !== color) {
      toast.error(`Game Over! Your score: ${score}`);
      setSequence([]);
      setUserSequence([]);
      setCurrentIndex(0);
      setScore(0);
      return;
    }

    if (newUserSequence.length === sequence.length) {
      const newScore = score + 1;
      setScore(newScore);
      toast.success(`Level ${newScore} complete!`);
      
      setTimeout(() => {
        const newColor = colors[Math.floor(Math.random() * colors.length)];
        setSequence([...sequence, newColor]);
        setUserSequence([]);
        setCurrentIndex(0);
      }, 1000);
    } else {
      setCurrentIndex(currentIndex + 1);
    }
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-game-pink to-game-glow bg-clip-text text-transparent">
              Simon Says
            </h1>
            <p className="mt-4 text-muted-foreground">
              Score: <span className="text-primary font-bold">{score}</span>
            </p>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-w-2xl mx-auto space-y-8">
          {sequence.length === 0 ? (
            <div className="text-center">
              <Button
                onClick={startGame}
                size="lg"
                className="bg-primary hover:bg-primary/90"
              >
                Start Game
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              {colors.map((color) => (
                <Card
                  key={color}
                  onClick={() => handleColorClick(color)}
                  className={`aspect-square cursor-pointer transition-all duration-200 border-2 border-border
                    ${colorClasses[color as keyof typeof colorClasses]}
                    ${activeColor === color ? 'scale-95 brightness-150' : ''}
                    ${isPlaying ? 'cursor-not-allowed opacity-50' : 'hover:scale-105 hover:border-white'}`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SimonSays;
