import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";
import DifficultySelector, { Difficulty } from "@/components/DifficultySelector";

type Grid = number[][];

const GRID_WIDTH = 10;
const GRID_HEIGHT = 20;

const DIFFICULTY_SPEEDS = {
  easy: 1200,
  medium: 800,
  hard: 500,
};

const Tetris = () => {
  const [grid, setGrid] = useState<Grid>([]);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPiece, setCurrentPiece] = useState({ x: 4, y: 0, shape: [[1,1,1,1]] });
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const { toast } = useToast();
  const audio = useGameAudio();

  useEffect(() => {
    initializeGrid();
  }, []);

  const initializeGrid = () => {
    const newGrid = Array(GRID_HEIGHT).fill(null).map(() => Array(GRID_WIDTH).fill(0));
    setGrid(newGrid);
  };

  const startGame = () => {
    initializeGrid();
    setScore(0);
    setIsPlaying(true);
    toast({ title: "Game Started!", description: "Use arrow keys to play" });
  };

  useEffect(() => {
    if (!isPlaying) return;

    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") movePiece(-1, 0);
      if (e.key === "ArrowRight") movePiece(1, 0);
      if (e.key === "ArrowDown") movePiece(0, 1);
      if (e.key === "ArrowUp") rotatePiece();
    };

    window.addEventListener("keydown", handleKeyPress);
    const dropSpeed = DIFFICULTY_SPEEDS[difficulty];
    const interval = setInterval(() => movePiece(0, 1), dropSpeed);

    return () => {
      window.removeEventListener("keydown", handleKeyPress);
      clearInterval(interval);
    };
  }, [isPlaying, currentPiece, difficulty]);

  const movePiece = (dx: number, dy: number) => {
    setCurrentPiece(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
  };

  const rotatePiece = () => {
    // Simplified rotation logic
    setCurrentPiece(prev => ({
      ...prev,
      shape: prev.shape[0].map((_, i) => prev.shape.map(row => row[i]).reverse())
    }));
  };

  const getCellColor = (value: number) => {
    if (value === 0) return "bg-card";
    return "bg-primary";
  };

  return (
    <>
      <Helmet>
        <title>Tetris - Classic Block Puzzle Game | Game Arena</title>
        <meta name="description" content="Play the classic Tetris game online. Arrange falling blocks to clear lines and achieve the highest score in this timeless puzzle game." />
        <meta name="keywords" content="tetris, tetris game, block puzzle, puzzle game, classic tetris, tetris online" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Tetris
          </h1>
          <div className="text-2xl font-bold">Score: {score}</div>
        </div>

        <div className="mb-6">
          <AudioControls
            volume={audio.volume}
            isMuted={audio.isMuted}
            onVolumeChange={audio.setVolume}
            onToggleMute={audio.toggleMute}
          />
        </div>

        <div className="mb-6">
          <DifficultySelector
            difficulty={difficulty}
            onDifficultyChange={setDifficulty}
            disabled={isPlaying}
          />
        </div>

        <div className="flex justify-center mb-6">
          <Card className="p-4">
            <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${GRID_WIDTH}, 1fr)` }}>
              {grid.map((row, y) =>
                row.map((cell, x) => (
                  <div
                    key={`${y}-${x}`}
                    className={`w-6 h-6 border ${getCellColor(cell)}`}
                  />
                ))
              )}
            </div>
          </Card>
        </div>

        <div className="text-center">
          {!isPlaying ? (
            <Button onClick={startGame} size="lg">Start Game</Button>
          ) : (
            <div className="text-muted-foreground">Use Arrow Keys to Play</div>
          )}
        </div>
      </div>
    </div>
    </>
  );
};

export default Tetris;
