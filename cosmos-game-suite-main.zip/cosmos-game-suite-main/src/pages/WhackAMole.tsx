import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Helmet } from "react-helmet";

const WhackAMole = () => {
  const [moles, setMoles] = useState<boolean[]>(Array(9).fill(false));
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [highScore, setHighScore] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setIsPlaying(true);
    setMoles(Array(9).fill(false));
  };

  useEffect(() => {
    if (!isPlaying) return;

    const moleInterval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * 9);
      setMoles(prev => {
        const newMoles = Array(9).fill(false);
        newMoles[randomIndex] = true;
        return newMoles;
      });
    }, 800);

    intervalRef.current = moleInterval;

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying]);

  useEffect(() => {
    if (!isPlaying) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setIsPlaying(false);
          if (score > highScore) {
            setHighScore(score);
            toast.success(`New high score: ${score}! 🎉`);
          } else {
            toast(`Game Over! Score: ${score}`);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, score, highScore]);

  const handleMoleClick = (index: number) => {
    if (!isPlaying || !moles[index]) return;
    
    setScore(score + 1);
    setMoles(prev => {
      const newMoles = [...prev];
      newMoles[index] = false;
      return newMoles;
    });
  };

  return (
    <>
      <Helmet>
        <title>Whack-a-Mole - Classic Arcade Game | Game Arena</title>
        <meta name="description" content="Play the classic Whack-a-Mole arcade game online. Test your reflexes and reaction time in this fun and addictive game." />
        <meta name="keywords" content="whack a mole, whack-a-mole game, arcade game, reaction game, reflex game" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-game-pink bg-clip-text text-transparent">
              Whack-a-Mole
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>Time: <span className="text-secondary font-bold">{timeLeft}s</span></span>
              <span>Best: <span className="text-game-pink font-bold">{highScore}</span></span>
            </div>
          </div>

          <Button
            variant="outline"
            size="icon"
            onClick={startGame}
            className="border-border hover:border-primary"
          >
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="max-w-2xl mx-auto space-y-8">
          {!isPlaying && timeLeft === 30 ? (
            <div className="text-center">
              <Button
                onClick={startGame}
                size="lg"
                className="bg-primary hover:bg-primary/90"
              >
                Start Game
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              {moles.map((isMoleVisible, index) => (
                <Card
                  key={index}
                  onClick={() => handleMoleClick(index)}
                  className={`aspect-square flex items-center justify-center text-6xl cursor-pointer transition-all duration-200 border-border
                    ${isMoleVisible 
                      ? 'bg-gradient-to-br from-primary to-game-pink border-primary hover:scale-95' 
                      : 'bg-card hover:border-muted'
                    }`}
                >
                  {isMoleVisible && <span className="animate-scale-in">🐹</span>}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
    </>
  );
};

export default WhackAMole;
