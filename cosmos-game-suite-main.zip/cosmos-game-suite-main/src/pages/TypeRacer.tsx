import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

const sentences = [
  "The quick brown fox jumps over the lazy dog.",
  "Practice makes perfect in everything you do.",
  "TypeScript is a typed superset of JavaScript.",
  "React is a JavaScript library for building user interfaces.",
  "Coding is not just about writing code, it's about solving problems."
];

const TypeRacer = () => {
  const [targetText, setTargetText] = useState("");
  const [userInput, setUserInput] = useState("");
  const [startTime, setStartTime] = useState<number | null>(null);
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [isComplete, setIsComplete] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    startNewRace();
  }, []);

  const startNewRace = () => {
    const randomSentence = sentences[Math.floor(Math.random() * sentences.length)];
    setTargetText(randomSentence);
    setUserInput("");
    setStartTime(null);
    setWpm(0);
    setAccuracy(100);
    setIsComplete(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleInputChange = (value: string) => {
    if (!startTime) {
      setStartTime(Date.now());
    }

    setUserInput(value);

    // Calculate accuracy
    let correct = 0;
    for (let i = 0; i < value.length; i++) {
      if (value[i] === targetText[i]) correct++;
    }
    const acc = value.length > 0 ? Math.round((correct / value.length) * 100) : 100;
    setAccuracy(acc);

    // Check completion
    if (value === targetText) {
      const timeElapsed = (Date.now() - (startTime || Date.now())) / 1000 / 60; // minutes
      const words = targetText.split(" ").length;
      const calculatedWpm = Math.round(words / timeElapsed);
      setWpm(calculatedWpm);
      setIsComplete(true);
      toast({ title: "Race Complete!", description: `${calculatedWpm} WPM with ${acc}% accuracy` });
    }
  };

  const getCharColor = (index: number) => {
    if (index >= userInput.length) return "text-muted-foreground";
    return userInput[index] === targetText[index] ? "text-primary" : "text-destructive";
  };

  return (
    <>
      <Helmet>
        <title>Type Racer - Typing Speed Test | Game Arena</title>
        <meta name="description" content="Test and improve your typing speed with Type Racer. Race against time and improve your WPM and accuracy!" />
        <meta name="keywords" content="type racer, typing test, typing speed, wpm test, typing game, typing practice" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Type Racer
          </h1>
          <Button onClick={startNewRace}>New Race</Button>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">WPM</div>
            <div className="text-4xl text-primary">{wpm}</div>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">Accuracy</div>
            <div className="text-4xl text-secondary">{accuracy}%</div>
          </Card>
        </div>

        <Card className="p-8 mb-6">
          <div className="text-2xl font-mono mb-6 leading-relaxed">
            {targetText.split("").map((char, index) => (
              <span key={index} className={getCharColor(index)}>
                {char}
              </span>
            ))}
          </div>

          <Input
            ref={inputRef}
            value={userInput}
            onChange={(e) => handleInputChange(e.target.value)}
            disabled={isComplete}
            placeholder="Start typing..."
            className="text-xl h-14"
          />
        </Card>

        {isComplete && (
          <Card className="p-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Race Complete! 🏁</h2>
            <div className="text-xl text-muted-foreground mb-6">
              You typed at <span className="text-primary font-bold">{wpm} WPM</span> with{" "}
              <span className="text-secondary font-bold">{accuracy}% accuracy</span>
            </div>
            <Button onClick={startNewRace} size="lg">Race Again</Button>
          </Card>
        )}
      </div>
    </div>
    </>
  );
};

export default TypeRacer;
