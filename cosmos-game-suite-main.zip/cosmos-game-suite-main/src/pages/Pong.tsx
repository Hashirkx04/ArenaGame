import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Helmet } from "react-helmet";

const Pong = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState({ player: 0, ai: 0 });
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const ball = { x: 400, y: 300, dx: 4, dy: 4, radius: 8 };
    const paddleHeight = 100;
    const paddleWidth = 10;
    const player = { x: 10, y: 250, score: 0 };
    const ai = { x: 780, y: 250, score: 0 };

    const drawRect = (x: number, y: number, w: number, h: number, color: string) => {
      ctx.fillStyle = color;
      ctx.fillRect(x, y, w, h);
    };

    const drawCircle = (x: number, y: number, r: number, color: string) => {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    };

    const update = () => {
      ball.x += ball.dx;
      ball.y += ball.dy;

      if (ball.y + ball.radius > 600 || ball.y - ball.radius < 0) {
        ball.dy *= -1;
      }

      // Player paddle collision
      if (
        ball.x - ball.radius < player.x + paddleWidth &&
        ball.x + ball.radius > player.x &&
        ball.y > player.y &&
        ball.y < player.y + paddleHeight
      ) {
        ball.dx = Math.abs(ball.dx);
        const hitPos = (ball.y - player.y) / paddleHeight;
        ball.dy = (hitPos - 0.5) * 8;
      }

      // AI paddle collision
      if (
        ball.x + ball.radius > ai.x &&
        ball.x - ball.radius < ai.x + paddleWidth &&
        ball.y > ai.y &&
        ball.y < ai.y + paddleHeight
      ) {
        ball.dx = -Math.abs(ball.dx);
        const hitPos = (ball.y - ai.y) / paddleHeight;
        ball.dy = (hitPos - 0.5) * 8;
      }

      if (ball.x - ball.radius < 0) {
        ai.score++;
        setScore({ player: player.score, ai: ai.score });
        ball.x = 400;
        ball.y = 300;
        ball.dx = 4;
        ball.dy = 4;
      }

      if (ball.x + ball.radius > 800) {
        player.score++;
        setScore({ player: player.score, ai: ai.score });
        ball.x = 400;
        ball.y = 300;
        ball.dx = -4;
        ball.dy = 4;
      }

      ai.y += (ball.y - (ai.y + paddleHeight / 2)) * 0.1;
    };

    const render = () => {
      drawRect(0, 0, 800, 600, "#1a1a1a");
      drawRect(player.x, player.y, paddleWidth, paddleHeight, "#fff");
      drawRect(ai.x, ai.y, paddleWidth, paddleHeight, "#fff");
      drawCircle(ball.x, ball.y, ball.radius, "#fff");
    };

    const gameLoop = () => {
      update();
      render();
      requestAnimationFrame(gameLoop);
    };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      player.y = e.clientY - rect.top - paddleHeight / 2;
    };

    canvas.addEventListener("mousemove", handleMouseMove);
    gameLoop();

    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove);
    };
  }, [isPlaying]);

  return (
    <>
      <Helmet>
        <title>Pong - Classic Arcade Game | Game Arena</title>
        <meta name="description" content="Play the classic Pong arcade game online. Control your paddle and compete against AI in this retro tennis game." />
        <meta name="keywords" content="pong, pong game, arcade game, retro game, paddle game, classic pong" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Pong
          </h1>
          <div className="text-2xl font-bold">
            {score.player} - {score.ai}
          </div>
        </div>

        <Card className="p-4">
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            className="w-full border rounded"
          />
        </Card>

        <div className="text-center mt-6">
          {!isPlaying ? (
            <Button onClick={() => setIsPlaying(true)} size="lg">Start Game</Button>
          ) : (
            <Button onClick={() => setIsPlaying(false)} variant="outline">Pause</Button>
          )}
        </div>
      </div>
    </div>
    </>
  );
};

export default Pong;
