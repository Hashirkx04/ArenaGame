import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

type Choice = "rock" | "paper" | "scissors";

const RockPaperScissors = () => {
  const [playerChoice, setPlayerChoice] = useState<Choice | null>(null);
  const [aiChoice, setAiChoice] = useState<Choice | null>(null);
  const [score, setScore] = useState({ player: 0, ai: 0, draws: 0 });
  const [result, setResult] = useState("");
  const { toast } = useToast();

  const choices: Choice[] = ["rock", "paper", "scissors"];

  const determineWinner = (player: Choice, ai: Choice) => {
    if (player === ai) return "draw";
    if (
      (player === "rock" && ai === "scissors") ||
      (player === "paper" && ai === "rock") ||
      (player === "scissors" && ai === "paper")
    ) {
      return "player";
    }
    return "ai";
  };

  const handleChoice = (choice: Choice) => {
    const ai = choices[Math.floor(Math.random() * choices.length)];
    setPlayerChoice(choice);
    setAiChoice(ai);

    const winner = determineWinner(choice, ai);
    
    if (winner === "player") {
      setScore(prev => ({ ...prev, player: prev.player + 1 }));
      setResult("You Win!");
      toast({ title: "You Win!", description: `${choice} beats ${ai}` });
    } else if (winner === "ai") {
      setScore(prev => ({ ...prev, ai: prev.ai + 1 }));
      setResult("AI Wins!");
      toast({ title: "AI Wins!", description: `${ai} beats ${choice}`, variant: "destructive" });
    } else {
      setScore(prev => ({ ...prev, draws: prev.draws + 1 }));
      setResult("Draw!");
      toast({ title: "Draw!", description: "Try again!" });
    }
  };

  const getEmoji = (choice: Choice | null) => {
    if (!choice) return "❓";
    if (choice === "rock") return "🪨";
    if (choice === "paper") return "📄";
    return "✂️";
  };

  return (
    <>
      <Helmet>
        <title>Rock Paper Scissors - Classic Hand Game | Game Arena</title>
        <meta name="description" content="Play Rock Paper Scissors online against AI. Make your choice and see if you can beat the computer in this classic game." />
        <meta name="keywords" content="rock paper scissors, rps game, hand game, rock paper scissors online" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Rock Paper Scissors
          </h1>
          <Button onClick={() => { setScore({ player: 0, ai: 0, draws: 0 }); setResult(""); }}>
            Reset
          </Button>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">You</div>
            <div className="text-4xl">{score.player}</div>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">Draws</div>
            <div className="text-4xl">{score.draws}</div>
          </Card>
          <Card className="p-6 text-center">
            <div className="text-xl font-bold mb-2">AI</div>
            <div className="text-4xl">{score.ai}</div>
          </Card>
        </div>

        {result && (
          <Card className="p-8 mb-8 text-center">
            <h2 className="text-3xl font-bold mb-4">{result}</h2>
            <div className="flex justify-center gap-8 text-6xl">
              <div>
                <div className="text-sm text-muted-foreground mb-2">You</div>
                {getEmoji(playerChoice)}
              </div>
              <div className="text-4xl self-center">VS</div>
              <div>
                <div className="text-sm text-muted-foreground mb-2">AI</div>
                {getEmoji(aiChoice)}
              </div>
            </div>
          </Card>
        )}

        <div className="grid grid-cols-3 gap-4">
          {choices.map(choice => (
            <Card
              key={choice}
              className="p-8 text-center cursor-pointer hover:scale-105 transition-transform"
              onClick={() => handleChoice(choice)}
            >
              <div className="text-6xl mb-4">{getEmoji(choice)}</div>
              <div className="text-xl font-bold capitalize">{choice}</div>
            </Card>
          ))}
        </div>
      </div>
    </div>
    </>
  );
};

export default RockPaperScissors;
