import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

const words = ["JAVASCRIPT", "TYPESCRIPT", "REACT", "COMPONENT", "FUNCTION", "VARIABLE", "ALGORITHM", "DATABASE", "FRONTEND", "BACKEND"];
const maxWrongGuesses = 6;

const Hangman = () => {
  const [word, setWord] = useState("");
  const [guessedLetters, setGuessedLetters] = useState<string[]>([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing");
  const { toast } = useToast();

  useEffect(() => {
    startNewGame();
  }, []);

  const startNewGame = () => {
    setWord(words[Math.floor(Math.random() * words.length)]);
    setGuessedLetters([]);
    setWrongGuesses(0);
    setGameStatus("playing");
  };

  const handleLetterClick = (letter: string) => {
    if (guessedLetters.includes(letter) || gameStatus !== "playing") return;

    const newGuessed = [...guessedLetters, letter];
    setGuessedLetters(newGuessed);

    if (!word.includes(letter)) {
      const newWrong = wrongGuesses + 1;
      setWrongGuesses(newWrong);
      
      if (newWrong >= maxWrongGuesses) {
        setGameStatus("lost");
        toast({ title: "Game Over!", description: `The word was ${word}`, variant: "destructive" });
      }
    } else {
      const allLettersGuessed = word.split("").every(l => newGuessed.includes(l));
      if (allLettersGuessed) {
        setGameStatus("won");
        toast({ title: "You Won!", description: "Congratulations!" });
      }
    }
  };

  const displayWord = word.split("").map(letter => 
    guessedLetters.includes(letter) ? letter : "_"
  ).join(" ");

  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  return (
    <>
      <Helmet>
        <title>Hangman - Word Guessing Game | Game Arena</title>
        <meta name="description" content="Play Hangman online and guess the hidden word before running out of chances. Test your vocabulary and logic skills." />
        <meta name="keywords" content="hangman, hangman game, word guessing game, word game, vocabulary game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Hangman
          </h1>
          <Button onClick={startNewGame}>New Game</Button>
        </div>

        <Card className="p-8 mb-6">
          <div className="text-center mb-8">
            <div className="text-6xl font-mono mb-4">{displayWord}</div>
            <div className="text-2xl text-muted-foreground">
              Wrong Guesses: {wrongGuesses} / {maxWrongGuesses}
            </div>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {alphabet.map(letter => (
              <Button
                key={letter}
                onClick={() => handleLetterClick(letter)}
                disabled={guessedLetters.includes(letter) || gameStatus !== "playing"}
                variant={guessedLetters.includes(letter) ? (word.includes(letter) ? "default" : "destructive") : "outline"}
                className="h-12"
              >
                {letter}
              </Button>
            ))}
          </div>
        </Card>

        {gameStatus !== "playing" && (
          <div className="text-center">
            <Button onClick={startNewGame} size="lg">Play Again</Button>
          </div>
        )}
      </div>
    </div>
    </>
  );
};

export default Hangman;
