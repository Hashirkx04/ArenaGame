import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Helmet } from "react-helmet";

const DiceRoll = () => {
  const [dice, setDice] = useState([1, 1]);
  const [isRolling, setIsRolling] = useState(false);
  const [history, setHistory] = useState<number[]>([]);

  const diceEmojis = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];

  const rollDice = () => {
    setIsRolling(true);
    
    let rolls = 0;
    const interval = setInterval(() => {
      setDice([
        Math.floor(Math.random() * 6) + 1,
        Math.floor(Math.random() * 6) + 1
      ]);
      rolls++;
      
      if (rolls >= 10) {
        clearInterval(interval);
        const final1 = Math.floor(Math.random() * 6) + 1;
        const final2 = Math.floor(Math.random() * 6) + 1;
        setDice([final1, final2]);
        setHistory([final1 + final2, ...history.slice(0, 9)]);
        setIsRolling(false);
      }
    }, 100);
  };

  const total = dice[0] + dice[1];

  return (
    <>
      <Helmet>
        <title>Dice Roll - Roll Virtual Dice | Game Arena</title>
        <meta name="description" content="Roll virtual dice online with realistic animations. Perfect for board games, decision making, or just for fun!" />
        <meta name="keywords" content="dice roll, dice roller, virtual dice, roll dice online, dice game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Dice Roll
          </h1>
          <div className="w-20"></div>
        </div>

        <Card className="p-12 mb-8">
          <div className="flex justify-center gap-8 mb-8">
            {dice.map((die, index) => (
              <div
                key={index}
                className={`text-9xl transition-transform ${isRolling ? "animate-bounce" : ""}`}
              >
                {diceEmojis[die - 1]}
              </div>
            ))}
          </div>

          <div className="text-center mb-8">
            <div className="text-6xl font-bold text-primary mb-2">{total}</div>
            <div className="text-xl text-muted-foreground">Total</div>
          </div>

          <div className="text-center">
            <Button
              onClick={rollDice}
              disabled={isRolling}
              size="lg"
              className="px-12"
            >
              {isRolling ? "Rolling..." : "Roll Dice"}
            </Button>
          </div>
        </Card>

        {history.length > 0 && (
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">Roll History</h2>
            <div className="flex gap-2 flex-wrap">
              {history.map((roll, index) => (
                <div
                  key={index}
                  className="w-12 h-12 bg-primary/20 rounded flex items-center justify-center font-bold"
                >
                  {roll}
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
    </>
  );
};

export default DiceRoll;
