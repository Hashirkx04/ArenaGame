import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw, Play, Pause } from "lucide-react";
import { toast } from "sonner";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";
import DifficultySelector, { Difficulty } from "@/components/DifficultySelector";

type Position = { x: number; y: number };
type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";

const GRID_SIZE = 20;
const CELL_SIZE = 20;
const INITIAL_SNAKE = [{ x: 10, y: 10 }];
const INITIAL_DIRECTION: Direction = "RIGHT";

const DIFFICULTY_SPEEDS = {
  easy: 200,
  medium: 150,
  hard: 100,
};

const SnakeGame = () => {
  const [snake, setSnake] = useState<Position[]>(INITIAL_SNAKE);
  const [food, setFood] = useState<Position>({ x: 15, y: 15 });
  const [direction, setDirection] = useState<Direction>(INITIAL_DIRECTION);
  const [nextDirection, setNextDirection] = useState<Direction>(INITIAL_DIRECTION);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const audio = useGameAudio();

  const generateFood = useCallback((snakeBody: Position[]) => {
    let newFood: Position;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
    } while (snakeBody.some(segment => segment.x === newFood.x && segment.y === newFood.y));
    return newFood;
  }, []);

  const resetGame = () => {
    setSnake(INITIAL_SNAKE);
    setDirection(INITIAL_DIRECTION);
    setNextDirection(INITIAL_DIRECTION);
    setFood(generateFood(INITIAL_SNAKE));
    setScore(0);
    setIsPlaying(false);
  };

  const gameOver = useCallback(() => {
    audio.playGameOverSound();
    setIsPlaying(false);
    if (score > highScore) {
      setHighScore(score);
      toast.success(`New High Score: ${score}!`);
    } else {
      toast.error(`Game Over! Score: ${score}`);
    }
  }, [score, highScore]);

  const moveSnake = useCallback(() => {
    setDirection(nextDirection);
    
    setSnake(prevSnake => {
      const head = { ...prevSnake[0] };
      
      switch (nextDirection) {
        case "UP": head.y -= 1; break;
        case "DOWN": head.y += 1; break;
        case "LEFT": head.x -= 1; break;
        case "RIGHT": head.x += 1; break;
      }

      // Check wall collision
      if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
        gameOver();
        return prevSnake;
      }

      // Check self collision
      if (prevSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
        gameOver();
        return prevSnake;
      }

      const newSnake = [head, ...prevSnake];

      // Check food collision
      if (head.x === food.x && head.y === food.y) {
        audio.playCollectSound();
        setScore(prev => prev + 10);
        setFood(generateFood(newSnake));
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [nextDirection, food, generateFood, gameOver]);

  useEffect(() => {
    if (!isPlaying) return;

    const gameSpeed = DIFFICULTY_SPEEDS[difficulty];
    const interval = setInterval(moveSnake, gameSpeed);
    return () => clearInterval(interval);
  }, [isPlaying, moveSnake, difficulty]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!isPlaying && e.code === "Space") {
        setIsPlaying(true);
        return;
      }

      switch (e.key) {
        case "ArrowUp":
          if (direction !== "DOWN") setNextDirection("UP");
          break;
        case "ArrowDown":
          if (direction !== "UP") setNextDirection("DOWN");
          break;
        case "ArrowLeft":
          if (direction !== "RIGHT") setNextDirection("LEFT");
          break;
        case "ArrowRight":
          if (direction !== "LEFT") setNextDirection("RIGHT");
          break;
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [direction, isPlaying]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Snake Game
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>High Score: <span className="text-secondary font-bold">{highScore}</span></span>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setIsPlaying(!isPlaying)}
              className="border-border hover:border-primary"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={resetGame}
              className="border-border hover:border-primary"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <AudioControls
            volume={audio.volume}
            isMuted={audio.isMuted}
            onVolumeChange={audio.setVolume}
            onToggleMute={audio.toggleMute}
          />
        </div>

        <div className="mb-6">
          <DifficultySelector
            difficulty={difficulty}
            onDifficultyChange={setDifficulty}
            disabled={isPlaying}
          />
        </div>

        <Card className="max-w-fit mx-auto p-4 bg-card border-border">
          <div
            style={{
              width: GRID_SIZE * CELL_SIZE,
              height: GRID_SIZE * CELL_SIZE,
              position: "relative",
              backgroundColor: "hsl(var(--background))",
            }}
          >
            {snake.map((segment, index) => (
              <div
                key={index}
                style={{
                  position: "absolute",
                  left: segment.x * CELL_SIZE,
                  top: segment.y * CELL_SIZE,
                  width: CELL_SIZE - 2,
                  height: CELL_SIZE - 2,
                  backgroundColor: index === 0 ? "hsl(var(--primary))" : "hsl(var(--secondary))",
                  borderRadius: "4px",
                  transition: "all 0.1s",
                }}
              />
            ))}
            <div
              style={{
                position: "absolute",
                left: food.x * CELL_SIZE,
                top: food.y * CELL_SIZE,
                width: CELL_SIZE - 2,
                height: CELL_SIZE - 2,
                backgroundColor: "hsl(var(--game-pink))",
                borderRadius: "50%",
              }}
            />
          </div>
        </Card>

        {!isPlaying && (
          <p className="text-center mt-4 text-muted-foreground">
            Press SPACE or ▶️ to start. Use arrow keys to move.
          </p>
        )}
      </div>
    </div>
  );
};

export default SnakeGame;
