import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Helmet } from "react-helmet";

const Platformer = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);

  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const player = {
      x: 50,
      y: 400,
      width: 30,
      height: 30,
      velocityY: 0,
      jumping: false
    };

    const platforms = [
      { x: 0, y: 450, width: 200, height: 20 },
      { x: 250, y: 400, width: 150, height: 20 },
      { x: 450, y: 350, width: 150, height: 20 },
      { x: 650, y: 300, width: 100, height: 20 }
    ];

    const coins: any[] = [
      { x: 300, y: 350, collected: false },
      { x: 500, y: 300, collected: false },
      { x: 700, y: 250, collected: false }
    ];

    let currentScore = 0;
    const gravity = 0.5;
    const jumpPower = -12;
    let keys: any = {};

    const drawPlayer = () => {
      ctx.fillStyle = "#3b82f6";
      ctx.fillRect(player.x, player.y, player.width, player.height);
    };

    const drawPlatforms = () => {
      ctx.fillStyle = "#22c55e";
      platforms.forEach(platform => {
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      });
    };

    const drawCoins = () => {
      coins.forEach(coin => {
        if (!coin.collected) {
          ctx.fillStyle = "#fbbf24";
          ctx.beginPath();
          ctx.arc(coin.x, coin.y, 10, 0, Math.PI * 2);
          ctx.fill();
        }
      });
    };

    const update = () => {
      // Apply gravity
      player.velocityY += gravity;
      player.y += player.velocityY;

      // Check platform collisions
      let onPlatform = false;
      platforms.forEach(platform => {
        if (
          player.x < platform.x + platform.width &&
          player.x + player.width > platform.x &&
          player.y + player.height < platform.y + platform.height &&
          player.y + player.height + player.velocityY >= platform.y
        ) {
          player.y = platform.y - player.height;
          player.velocityY = 0;
          player.jumping = false;
          onPlatform = true;
        }
      });

      // Game over if fall off screen
      if (player.y > 600) {
        setGameOver(true);
        setIsPlaying(false);
        return;
      }

      // Movement
      if (keys['ArrowLeft'] && player.x > 0) {
        player.x -= 5;
      }
      if (keys['ArrowRight'] && player.x < 770) {
        player.x += 5;
      }
      if (keys['ArrowUp'] && !player.jumping) {
        player.velocityY = jumpPower;
        player.jumping = true;
      }

      // Collect coins
      coins.forEach(coin => {
        if (!coin.collected) {
          const dx = player.x + player.width / 2 - coin.x;
          const dy = player.y + player.height / 2 - coin.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 20) {
            coin.collected = true;
            currentScore += 10;
            setScore(currentScore);
          }
        }
      });
    };

    const render = () => {
      ctx.fillStyle = "#1a1a1a";
      ctx.fillRect(0, 0, 800, 600);
      drawPlatforms();
      drawCoins();
      drawPlayer();
    };

    const gameLoop = () => {
      if (gameOver) return;
      update();
      render();
      requestAnimationFrame(gameLoop);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key] = true;
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key] = false;
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    gameLoop();

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isPlaying, gameOver]);

  const resetGame = () => {
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
  };

  return (
    <>
      <Helmet>
        <title>Platformer - Jump and Collect Coins | Game Arena</title>
        <meta name="description" content="Play our platformer game online. Jump across platforms and collect coins in this classic side-scrolling adventure!" />
        <meta name="keywords" content="platformer game, platform jumper, coin collector, arcade game, jumping game" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <Link to="/">
              <Button variant="outline" size="icon">
                <Home className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Platform Jumper
            </h1>
            <div className="text-2xl font-bold">Score: {score}</div>
          </div>

          <Card className="p-4">
            <canvas
              ref={canvasRef}
              width={800}
              height={600}
              className="w-full border rounded"
            />
          </Card>

          <div className="text-center mt-6">
            {!isPlaying && !gameOver ? (
              <Button onClick={() => setIsPlaying(true)} size="lg">Start Game</Button>
            ) : gameOver ? (
              <div className="space-y-4">
                <p className="text-xl text-muted-foreground">Game Over! Score: {score}</p>
                <Button onClick={resetGame} size="lg">Play Again</Button>
              </div>
            ) : (
              <p className="text-muted-foreground">Use Arrow Keys to Move and Jump</p>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Platformer;
