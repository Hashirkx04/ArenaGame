import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";
import { Helmet } from "react-helmet";

type Piece = string | null;
type Board = Piece[][];

const Chess = () => {
  const initialBoard: Board = [
    ["♜", "♞", "♝", "♛", "♚", "♝", "♞", "♜"],
    ["♟", "♟", "♟", "♟", "♟", "♟", "♟", "♟"],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    [null, null, null, null, null, null, null, null],
    ["♙", "♙", "♙", "♙", "♙", "♙", "♙", "♙"],
    ["♖", "♘", "♗", "♕", "♔", "♗", "♘", "♖"]
  ];

  const [board, setBoard] = useState<Board>(initialBoard);
  const [selectedSquare, setSelectedSquare] = useState<[number, number] | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<"white" | "black">("white");

  const handleSquareClick = (row: number, col: number) => {
    if (!selectedSquare) {
      if (board[row][col]) {
        setSelectedSquare([row, col]);
      }
    } else {
      const [fromRow, fromCol] = selectedSquare;
      const newBoard = board.map(r => [...r]);
      newBoard[row][col] = newBoard[fromRow][fromCol];
      newBoard[fromRow][fromCol] = null;
      setBoard(newBoard);
      setSelectedSquare(null);
      setCurrentPlayer(currentPlayer === "white" ? "black" : "white");
    }
  };

  const resetGame = () => {
    setBoard(initialBoard);
    setSelectedSquare(null);
    setCurrentPlayer("white");
  };

  return (
    <>
      <Helmet>
        <title>Chess - Strategic Board Game | Game Arena</title>
        <meta name="description" content="Play Chess online, the classic strategic board game. Challenge yourself or play with a friend in this timeless game of tactics." />
        <meta name="keywords" content="chess, chess game, chess online, board game, strategy game, chess tactics" />
      </Helmet>
      <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Chess
          </h1>
          <Button onClick={resetGame}>Reset</Button>
        </div>

        <Card className="p-6 mb-4">
          <div className="text-center text-2xl font-bold mb-4 capitalize">
            {currentPlayer}'s Turn
          </div>
          
          <div className="inline-block">
            {board.map((row, rowIndex) => (
              <div key={rowIndex} className="flex">
                {row.map((piece, colIndex) => {
                  const isLight = (rowIndex + colIndex) % 2 === 0;
                  const isSelected = selectedSquare?.[0] === rowIndex && selectedSquare?.[1] === colIndex;
                  
                  return (
                    <button
                      key={colIndex}
                      onClick={() => handleSquareClick(rowIndex, colIndex)}
                      className={`w-16 h-16 flex items-center justify-center text-4xl border
                        ${isLight ? "bg-card" : "bg-accent"}
                        ${isSelected ? "ring-4 ring-primary" : ""}
                        hover:opacity-80 transition-opacity`}
                    >
                      {piece}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </Card>

        <div className="text-center text-sm text-muted-foreground">
          Click a piece to select, then click a square to move
        </div>
      </div>
    </div>
    </>
  );
};

export default Chess;
