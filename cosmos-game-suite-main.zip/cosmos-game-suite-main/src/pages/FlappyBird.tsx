import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";
import DifficultySelector, { Difficulty } from "@/components/DifficultySelector";

const FlappyBird = () => {
  const [birdY, setBirdY] = useState(250);
  const [birdVelocity, setBirdVelocity] = useState(0);
  const [pipes, setPipes] = useState<{ x: number; gap: number; y: number }[]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const gameRef = useRef<HTMLDivElement>(null);
  const audio = useGameAudio();

  const PIPE_WIDTH = 60;
  const BIRD_SIZE = 40;

  const DIFFICULTY_SETTINGS = {
    easy: { gravity: 0.5, jumpStrength: -9, pipeGap: 220, pipeSpeed: 2 },
    medium: { gravity: 0.6, jumpStrength: -10, pipeGap: 200, pipeSpeed: 3 },
    hard: { gravity: 0.7, jumpStrength: -11, pipeGap: 170, pipeSpeed: 4 },
  };

  const startGame = () => {
    const settings = DIFFICULTY_SETTINGS[difficulty];
    setBirdY(250);
    setBirdVelocity(0);
    setPipes([{ x: 400, gap: settings.pipeGap, y: Math.random() * 200 + 50 }]);
    setScore(0);
    setIsPlaying(true);
    setGameOver(false);
  };

  const jump = () => {
    if (!isPlaying && !gameOver) {
      startGame();
    } else if (isPlaying && !gameOver) {
      audio.playClickSound();
      const settings = DIFFICULTY_SETTINGS[difficulty];
      setBirdVelocity(settings.jumpStrength);
    }
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        jump();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isPlaying, gameOver]);

  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const settings = DIFFICULTY_SETTINGS[difficulty];

    const gameLoop = setInterval(() => {
      setBirdY(prev => {
        const newY = prev + birdVelocity;
        if (newY > 550 || newY < 0) {
          audio.playGameOverSound();
          setGameOver(true);
          setIsPlaying(false);
          if (score > highScore) {
            setHighScore(score);
            toast.success(`New high score: ${score}! 🎉`);
          } else {
            toast(`Game Over! Score: ${score}`);
          }
          return prev;
        }
        return newY;
      });

      setBirdVelocity(prev => prev + settings.gravity);

      setPipes(prev => {
        let newPipes = prev.map(pipe => ({ ...pipe, x: pipe.x - settings.pipeSpeed }));
        
        if (newPipes.length > 0 && newPipes[0].x < -PIPE_WIDTH) {
          newPipes.shift();
          audio.playCollectSound();
          setScore(s => s + 1);
        }

        if (newPipes.length === 0 || newPipes[newPipes.length - 1].x < 200) {
          newPipes.push({
            x: 400,
            gap: settings.pipeGap,
            y: Math.random() * 200 + 50
          });
        }

        newPipes.forEach(pipe => {
          if (
            birdY < pipe.y ||
            birdY + BIRD_SIZE > pipe.y + pipe.gap
          ) {
            if (pipe.x < 60 && pipe.x + PIPE_WIDTH > 20) {
              audio.playGameOverSound();
              setGameOver(true);
              setIsPlaying(false);
              if (score > highScore) {
                setHighScore(score);
                toast.success(`New high score: ${score}! 🎉`);
              } else {
                toast(`Game Over! Score: ${score}`);
              }
            }
          }
        });

        return newPipes;
      });
    }, 20);

    return () => clearInterval(gameLoop);
  }, [isPlaying, birdVelocity, birdY, gameOver, score, highScore, difficulty]);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-game opacity-20" />
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="border-border hover:border-primary">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="text-center flex-1">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-game-glow to-secondary bg-clip-text text-transparent">
              Flappy Bird
            </h1>
            <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
              <span>Score: <span className="text-primary font-bold">{score}</span></span>
              <span>Best: <span className="text-secondary font-bold">{highScore}</span></span>
            </div>
          </div>

          <div className="w-10" />
        </div>

        <div className="mb-6">
          <AudioControls
            volume={audio.volume}
            isMuted={audio.isMuted}
            onVolumeChange={audio.setVolume}
            onToggleMute={audio.toggleMute}
          />
        </div>

        <div className="mb-6">
          <DifficultySelector
            difficulty={difficulty}
            onDifficultyChange={setDifficulty}
            disabled={isPlaying}
          />
        </div>

        <div className="max-w-md mx-auto space-y-4">
          <div
            ref={gameRef}
            onClick={jump}
            className="relative w-full h-[600px] bg-gradient-to-b from-primary/20 to-secondary/20 border-2 border-border rounded-lg overflow-hidden cursor-pointer"
          >
            <div
              className="absolute w-10 h-10 flex items-center justify-center text-2xl transition-all"
              style={{ left: '20px', top: `${birdY}px` }}
            >
              🐦
            </div>

            {pipes.map((pipe, i) => (
              <div key={i}>
                <div
                  className="absolute bg-secondary"
                  style={{
                    left: `${pipe.x}px`,
                    top: 0,
                    width: `${PIPE_WIDTH}px`,
                    height: `${pipe.y}px`,
                  }}
                />
                <div
                  className="absolute bg-secondary"
                  style={{
                    left: `${pipe.x}px`,
                    top: `${pipe.y + pipe.gap}px`,
                    width: `${PIPE_WIDTH}px`,
                    height: `${600 - pipe.y - pipe.gap}px`,
                  }}
                />
              </div>
            ))}

            {!isPlaying && !gameOver && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80">
                <div className="text-center">
                  <p className="text-xl text-muted-foreground mb-4">Click or press Space to start</p>
                </div>
              </div>
            )}

            {gameOver && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/80">
                <div className="text-center">
                  <p className="text-2xl font-bold text-foreground mb-4">Game Over!</p>
                  <Button onClick={startGame} className="bg-primary hover:bg-primary/90">
                    Play Again
                  </Button>
                </div>
              </div>
            )}
          </div>
          <p className="text-center text-muted-foreground text-sm">Click or press Space to jump</p>
        </div>
      </div>
    </div>
  );
};

export default FlappyBird;
