import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Helmet } from "react-helmet";
import Footer from "@/components/Footer";
import AudioControls from "@/components/AudioControls";
import { useGameAudio } from "@/hooks/useGameAudio";

type Player = "X" | "O" | null;

const TicTacToe = () => {
  const [board, setBoard] = useState<Player[]>(Array(9).fill(null));
  const [currentPlayer, setCurrentPlayer] = useState<"X" | "O">("X");
  const [winner, setWinner] = useState<Player>(null);
  const [xScore, setXScore] = useState(0);
  const [oScore, setOScore] = useState(0);
  const audio = useGameAudio();

  const winningCombinations = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6] // Diagonals
  ];

  const checkWinner = (squares: Player[]) => {
    for (const [a, b, c] of winningCombinations) {
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  };

  const handleClick = (index: number) => {
    if (board[index] || winner) return;

    audio.playClickSound();
    const newBoard = [...board];
    newBoard[index] = currentPlayer;
    setBoard(newBoard);

    const gameWinner = checkWinner(newBoard);
    if (gameWinner) {
      setWinner(gameWinner);
      audio.playWinSound();
      if (gameWinner === "X") {
        setXScore(xScore + 1);
        toast.success("Player X wins! 🎉");
      } else {
        setOScore(oScore + 1);
        toast.success("Player O wins! 🎉");
      }
    } else if (newBoard.every(cell => cell !== null)) {
      audio.playErrorSound();
      toast("It's a draw!");
    } else {
      setCurrentPlayer(currentPlayer === "X" ? "O" : "X");
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setCurrentPlayer("X");
    setWinner(null);
  };

  const resetScores = () => {
    setXScore(0);
    setOScore(0);
    resetGame();
  };

  return (
    <>
      <Helmet>
        <title>Tic Tac Toe - Game Arena</title>
        <meta name="description" content="Play the classic Tic Tac Toe game. Challenge a friend in this timeless strategy game!" />
        <meta name="keywords" content="tic tac toe, noughts and crosses, strategy game, two player game" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-game opacity-20" />
        
        <div className="relative z-10 container mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-8">
            <Link to="/">
              <Button variant="outline" size="icon" className="border-border hover:border-primary">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            
            <div className="text-center flex-1">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Tic Tac Toe
              </h1>
              <div className="flex gap-8 justify-center mt-4 text-muted-foreground">
                <span>Player X: <span className="text-primary font-bold">{xScore}</span></span>
                <span>Player O: <span className="text-secondary font-bold">{oScore}</span></span>
              </div>
            </div>

            <Button
              variant="outline"
              size="icon"
              onClick={resetScores}
              className="border-border hover:border-primary"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>

          <div className="mb-6">
            <AudioControls
              volume={audio.volume}
              isMuted={audio.isMuted}
              onVolumeChange={audio.setVolume}
              onToggleMute={audio.toggleMute}
            />
          </div>

          <div className="max-w-md mx-auto space-y-6">
          <div className="text-center">
            <p className="text-xl text-muted-foreground">
              {winner 
                ? `Winner: Player ${winner}!` 
                : board.every(cell => cell !== null)
                ? "It's a Draw!"
                : `Current Player: ${currentPlayer}`
              }
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {board.map((cell, index) => (
              <Card
                key={index}
                onClick={() => handleClick(index)}
                className={`aspect-square flex items-center justify-center text-6xl font-bold cursor-pointer transition-all duration-300 hover:shadow-game border-border
                  ${!cell && !winner ? 'hover:border-primary' : ''} 
                  ${cell === 'X' ? 'bg-gradient-to-br from-primary to-game-glow' : ''}
                  ${cell === 'O' ? 'bg-gradient-to-br from-secondary to-game-purple' : ''}
                  ${!cell ? 'bg-card' : ''}`}
              >
                {cell && (
                  <span className="text-white animate-scale-in">
                    {cell}
                  </span>
                )}
              </Card>
            ))}
          </div>

          {(winner || board.every(cell => cell !== null)) && (
            <div className="text-center">
              <Button
                onClick={resetGame}
                className="bg-primary hover:bg-primary/90"
              >
                Play Again
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
    <Footer />
    </>
  );
};

export default TicTacToe;
