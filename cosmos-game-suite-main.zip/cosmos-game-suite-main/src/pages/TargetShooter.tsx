import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Play, Target as TargetIcon } from "lucide-react";
import { Helmet } from "react-helmet";
import Footer from "@/components/Footer";

interface Target {
  id: number;
  x: number;
  y: number;
  size: number;
}

const TargetShooter = () => {
  const [gameState, setGameState] = useState<"idle" | "playing" | "finished">("idle");
  const [targets, setTargets] = useState<Target[]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [missed, setMissed] = useState(0);
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const targetIdRef = useRef(0);

  useEffect(() => {
    const saved = localStorage.getItem("targetShooterHighScore");
    if (saved) setHighScore(parseInt(saved));
  }, []);

  useEffect(() => {
    if (gameState === "playing" && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      endGame();
    }
  }, [gameState, timeLeft]);

  useEffect(() => {
    if (gameState === "playing") {
      const interval = setInterval(spawnTarget, 1000);
      return () => clearInterval(interval);
    }
  }, [gameState]);

  const spawnTarget = () => {
    if (!gameAreaRef.current) return;

    const rect = gameAreaRef.current.getBoundingClientRect();
    const size = Math.random() * 40 + 30; // 30-70px
    
    const newTarget: Target = {
      id: targetIdRef.current++,
      x: Math.random() * (rect.width - size),
      y: Math.random() * (rect.height - size),
      size,
    };

    setTargets((prev) => [...prev, newTarget]);

    // Remove target after 2 seconds if not hit
    setTimeout(() => {
      setTargets((prev) => {
        const stillExists = prev.find(t => t.id === newTarget.id);
        if (stillExists) {
          setMissed(m => m + 1);
        }
        return prev.filter((t) => t.id !== newTarget.id);
      });
    }, 2000);
  };

  const hitTarget = (id: number, size: number) => {
    const points = Math.round(100 / size * 30); // Smaller targets = more points
    setScore((prev) => prev + points);
    setTargets((prev) => prev.filter((t) => t.id !== id));
  };

  const startGame = () => {
    setGameState("playing");
    setScore(0);
    setTimeLeft(30);
    setTargets([]);
    setMissed(0);
    targetIdRef.current = 0;
  };

  const endGame = () => {
    setGameState("finished");
    if (score > highScore) {
      setHighScore(score);
      localStorage.setItem("targetShooterHighScore", score.toString());
    }
  };

  const handleAreaClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setScore((prev) => Math.max(0, prev - 10));
    }
  };

  return (
    <>
      <Helmet>
        <title>Target Shooter - Game Arena</title>
        <meta name="description" content="Test your aim and precision! Hit the moving targets as fast as you can. Smaller targets give more points!" />
        <meta name="keywords" content="target shooter, aim game, precision game, click game, reflex game" />
      </Helmet>
      <div className="min-h-screen bg-background relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-game opacity-30" />
        
        <div className="relative z-10 container mx-auto px-4 py-8">
          <div className="flex items-center gap-4 mb-8">
            <Link to="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Target Shooter
            </h1>
          </div>

          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex justify-between items-center">
              <Card className="p-4 flex-1 mr-2 bg-gradient-card border-border">
                <p className="text-sm text-muted-foreground">Score</p>
                <p className="text-2xl font-bold text-primary">{score}</p>
              </Card>
              <Card className="p-4 flex-1 mx-2 bg-gradient-card border-border">
                <p className="text-sm text-muted-foreground">Time</p>
                <p className="text-2xl font-bold text-secondary">{timeLeft}s</p>
              </Card>
              <Card className="p-4 flex-1 mx-2 bg-gradient-card border-border">
                <p className="text-sm text-muted-foreground">Missed</p>
                <p className="text-2xl font-bold text-destructive">{missed}</p>
              </Card>
              <Card className="p-4 flex-1 ml-2 bg-gradient-card border-border">
                <p className="text-sm text-muted-foreground">High Score</p>
                <p className="text-2xl font-bold text-game-pink">{highScore}</p>
              </Card>
            </div>

            <Card className="p-8 bg-gradient-card border-border">
              {gameState === "idle" && (
                <div className="text-center space-y-4">
                  <TargetIcon className="w-20 h-20 mx-auto text-primary" />
                  <h2 className="text-2xl font-bold">Ready to Shoot?</h2>
                  <p className="text-muted-foreground">
                    Click the targets as fast as you can! Smaller targets = more points.
                    <br />
                    Missing costs 10 points. You have 30 seconds!
                  </p>
                  <Button onClick={startGame} size="lg">
                    <Play className="mr-2 h-4 w-4" />
                    Start Game
                  </Button>
                </div>
              )}

              {gameState === "playing" && (
                <div
                  ref={gameAreaRef}
                  onClick={handleAreaClick}
                  className="relative w-full h-96 bg-background/50 rounded-lg border-2 border-border cursor-crosshair"
                >
                  {targets.map((target) => (
                    <div
                      key={target.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        hitTarget(target.id, target.size);
                      }}
                      className="absolute rounded-full bg-gradient-to-br from-red-500 to-orange-500 cursor-pointer hover:scale-110 transition-transform animate-pulse"
                      style={{
                        left: `${target.x}px`,
                        top: `${target.y}px`,
                        width: `${target.size}px`,
                        height: `${target.size}px`,
                      }}
                    >
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-1/3 h-1/3 rounded-full bg-white" />
                      </div>
                    </div>
                  ))}
                  {targets.length === 0 && (
                    <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                      Targets incoming...
                    </div>
                  )}
                </div>
              )}

              {gameState === "finished" && (
                <div className="text-center space-y-4">
                  <h2 className="text-3xl font-bold">Game Over!</h2>
                  <p className="text-5xl font-bold text-primary">{score}</p>
                  <p className="text-muted-foreground">
                    Targets Hit: {Math.floor(score / 50)} | Missed: {missed}
                  </p>
                  {score > highScore && (
                    <p className="text-lg font-bold text-game-pink animate-pulse">
                      🎉 New High Score! 🎉
                    </p>
                  )}
                  <Button onClick={startGame} size="lg">
                    <Play className="mr-2 h-4 w-4" />
                    Play Again
                  </Button>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default TargetShooter;
